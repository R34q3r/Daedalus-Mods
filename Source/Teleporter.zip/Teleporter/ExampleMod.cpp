#include "ExampleMod.h"
#include "SDK.hpp"
#include "Utilities/MinHook.h"
#include "Ue4.hpp"
#include <filesystem>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <shlobj_core.h>
#include <direct.h>
#include <json/json.h>

BPFUNCTION(WriteToFile)
{
	std::cout << "WriteToFile" << std::endl;
	struct InputParams
	{
		UE4::FString NameTest;
	};
	auto Inputs = stack->GetInputParams<InputParams>();
	stack->SetOutput<UE4::FString>("OutPutString", L"KboyGang");
	stack->SetOutput<bool>("ReturnValue", true);
}

void LogOther(int32_t value)
{
	Log::Print(std::to_string(value));
}

// Only Called Once, if you need to hook shit, declare some global non changing values
void ExampleMod::InitializeMod()
{

	UE4::InitSDK();
	SetupHooks();

	REGISTER_FUNCTION(WriteToFile);

	MinHook::Init(); //Uncomment if you plan to do hooks

	UseMenuButton = true; // Allows Mod Loader To Show Button
}

void ExampleMod::InitGameState()
{
}

template<typename T>
static T* FindObject(const std::string& name)
{
	for (int i = 0; i < UE4::UObject::GObjects->GetAsChunckArray().Num(); ++i)
	{
		auto object = UE4::UObject::GObjects->GetAsChunckArray().GetByIndex(i).Object;

		if (object == nullptr)
		{
			continue;
		}

		if (object->GetFullName() == name)
		{
			return static_cast<T*>(object);
		}
	}
	return nullptr;
}

//Classes
UE4::UObject* InventoryItemLibrary;
UE4::UObject* InputSettingsClass;

//Functions
UE4::UFunction* GetBPIcarusPlayerController;
UE4::UFunction* K2_GetActorLocation;
UE4::UFunction* CreateCustomItem;
UE4::UFunction* DevTeleport;
UE4::UFunction* SetItem;
UE4::UFunction* RemoveItem;
UE4::UFunction* ActivateHotbarSlot;
UE4::UFunction* InpActEvt_HotbarForward_K2Node_InputActionEvent_5;
UE4::UFunction* SetFocusedSlot;

UE4::AActor* BP_IcarusPlayerControllerSurvival_C;
UE4::AActor* BP_IcarusPlayerCharacterSurvival_C;

UE4::TArray<FIcarusStatReplicated> stats;

void ExampleMod::ProcessFunction(UE4::UObject* pCallObject, UE4::UFunction* pUFunc, void* pParms)
{
	if (pUFunc->GetFullName() == "Function BP_IcarusPlayerCharacterSurvival.BP_IcarusPlayerCharacterSurvival_C.InpActEvt_Fire_K2Node_InputActionEvent_18")
	{
		UE4::UObject* UserInterface = *(UE4::UObject**)(BP_IcarusPlayerControllerSurvival_C + 0x8d8);

		UE4::UObject* HotBar = *(UE4::UObject**)(UserInterface + 0x560);

		int32_t slotIndex = *(int32_t*)(HotBar + 0x2f8);

		UE4::UObject* UInventory = *(UE4::UObject**)(BP_IcarusPlayerControllerSurvival_C + 0x8f0);

		UE4::UObject* FInventorySlotsFastArray = (UE4::UObject*)(UInventory + 0xe8);

		struct UE4::TArray<FInventorySlot> Slots = *(struct UE4::TArray<FInventorySlot>*)(FInventorySlotsFastArray + 0x108);

		std::string selectedItemName = Slots[slotIndex].ItemData.ItemStaticData.RowName.GetName();

		stats = Slots[slotIndex].ItemData.CustomProperties.Stats;

		if (selectedItemName == "Teleporter")
		{
			if (Slots[slotIndex].ItemData.CustomProperties.Stats.Count == 3)
			{
				struct
				{
					struct UE4::UObject* ReturnValue;
				}GetBPIcarusPlayerControllerParams;

				pCallObject->ProcessEvent(GetBPIcarusPlayerController, &GetBPIcarusPlayerControllerParams);

				struct
				{
					struct UE4::FVector Location;
					struct UE4::FRotator Rotation;
				}DevTeleportParams;

				DevTeleportParams.Location = { (float)Slots[slotIndex].ItemData.CustomProperties.Stats[0].Value, (float)Slots[slotIndex].ItemData.CustomProperties.Stats[1].Value, (float)Slots[slotIndex].ItemData.CustomProperties.Stats[2].Value };
				DevTeleportParams.Rotation = { 0, 0,0 };

				GetBPIcarusPlayerControllerParams.ReturnValue->ProcessEvent(DevTeleport, &DevTeleportParams);
			}
		}
	}
	else if (pUFunc->GetFullName() == "Function BP_IcarusPlayerCharacterSurvival.BP_IcarusPlayerCharacterSurvival_C.InpActEvt_AltFire_K2Node_InputActionEvent_14")
	{
		GameProfile::SelectedGameProfile.StaticLoadObject;

		UE4::UObject* UserInterface = *(UE4::UObject**)(BP_IcarusPlayerControllerSurvival_C + 0x8d8);

		UE4::UObject* HotBar = *(UE4::UObject**)(UserInterface + 0x560);

		int32_t slotIndex = *(int32_t*)(HotBar + 0x2f8);

		UE4::UObject* UInventory = *(UE4::UObject**)(BP_IcarusPlayerControllerSurvival_C + 0x8f0);

		UE4::UObject* FInventorySlotsFastArray = (UE4::UObject*)(UInventory + 0xe8);

		UE4::TArray<struct FInventorySlot> Slots = *(UE4::TArray<struct FInventorySlot>*)(FInventorySlotsFastArray + 0x108);

		std::string selectedItemName = Slots[slotIndex].ItemData.ItemStaticData.RowName.GetName();

		if (selectedItemName == "Teleporter")
		{
			struct
			{
				struct UE4::AActor* ReturnValue;
			}GetBPIcarusPlayerControllerParams;

			struct
			{
				struct UE4::FVector ReturnValue;
			}K2_GetActorLocationParams;

			struct
			{
				int32_t Location;
				struct FItemData NewItem;
				bool ReturnValue;
			}SetItemParams;

			struct
			{
				struct UE4::FKey Key;
			}InpActEvt_HotbarForward_K2Node_InputActionEvent_5Params;

			struct
			{
				int32_t Location;
				int32_t Amount;
				bool ClearItemSave;
				struct FItemData ReturnValue;
			}RemoveItemParams;

			struct
			{
				int32_t NewFocused;
				bool ForceSet;
			}SetFocusedSlotParams;

			struct
			{
				struct FItemData ItemData;
				struct UE4::TArray<struct FAlterationsEnum> Alterations;
				struct UE4::TArray<struct FIcarusStatReplicated> AdditionalStats;
				UE4::UObject* WorldContextObject;
				struct FItemData ReturnValue;
			}CreateCustomItemParams;

			pCallObject->ProcessEvent(GetBPIcarusPlayerController, &GetBPIcarusPlayerControllerParams);

			GetBPIcarusPlayerControllerParams.ReturnValue->ProcessEvent(K2_GetActorLocation, &K2_GetActorLocationParams);

			FIcarusStatReplicated locationX;
			FIcarusStatReplicated locationY;
			FIcarusStatReplicated locationZ;

			UE4::TArray<FIcarusStatReplicated> clearStats;

			Slots[slotIndex].ItemData.CustomProperties.Stats = clearStats;

			locationX.Value = K2_GetActorLocationParams.ReturnValue.X;
			locationY.Value = K2_GetActorLocationParams.ReturnValue.Y;
			locationZ.Value = K2_GetActorLocationParams.ReturnValue.Z;

			CreateCustomItemParams.ItemData = Slots[slotIndex].ItemData;
			CreateCustomItemParams.WorldContextObject = UE4::UWorld::GetWorld();

			CreateCustomItemParams.AdditionalStats.Add(locationX);
			CreateCustomItemParams.AdditionalStats.Add(locationY);
			CreateCustomItemParams.AdditionalStats.Add(locationZ);

			InventoryItemLibrary->ProcessEvent(CreateCustomItem, &CreateCustomItemParams);

			Slots[slotIndex].ItemData = CreateCustomItemParams.ReturnValue;

			SetItemParams.Location = slotIndex;
			SetItemParams.NewItem = CreateCustomItemParams.ReturnValue;

			RemoveItemParams.Location = slotIndex;
			RemoveItemParams.Amount = 0;
			RemoveItemParams.ClearItemSave = true;

			UInventory->ProcessEvent(RemoveItem, &RemoveItemParams);

			UInventory->ProcessEvent(SetItem, &SetItemParams);

			SetFocusedSlotParams.ForceSet = true;
			SetFocusedSlotParams.NewFocused = slotIndex;

			BP_IcarusPlayerCharacterSurvival_C->ProcessEvent(SetFocusedSlot, &SetFocusedSlotParams);
		}
	}
}

static UE4::APlayerController* GetPlayerController()
{
	static auto fn = FindObject<UE4::UFunction>("Function Engine.GameplayStatics.GetPlayerController");
	auto GameplayStatics = FindObject<UE4::UGameplayStatics>("Class Engine.GameplayStatics");

	struct
	{
		class UE4::UObject* WorldContextObject;
		int PlayerIndex;
		class UE4::APlayerController* ReturnValue;
	}params;

	params.WorldContextObject = UE4::UWorld::GetWorld();
	params.PlayerIndex = 0;

	GameplayStatics->ProcessEvent(fn, &params);

	return params.ReturnValue;
}

void ExampleMod::BeginPlay(UE4::AActor* Actor)
{
	if (Actor->GetClass()->GetFullName() == "BlueprintGeneratedClass BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C")
	{
		BP_IcarusPlayerControllerSurvival_C = Actor;

		//Classes
		InventoryItemLibrary = FindObject<UE4::UObject>("Class Icarus.InventoryItemLibrary");
		InputSettingsClass = FindObject<UE4::UObject>("Class Engine.InputSettings");

		//Functions
		GetBPIcarusPlayerController = FindObject<UE4::UFunction>("Function BP_IcarusPlayerCharacterSurvival.BP_IcarusPlayerCharacterSurvival_C.GetBPIcarusPlayerController");
		K2_GetActorLocation = FindObject<UE4::UFunction>("Function Engine.Actor.K2_GetActorLocation");
		CreateCustomItem = FindObject<UE4::UFunction>("Function Icarus.InventoryItemLibrary.CreateCustomItem");
		DevTeleport = FindObject<UE4::UFunction>("Function BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C.DevTeleport");
		GetBPIcarusPlayerController = FindObject<UE4::UFunction>("Function BP_IcarusPlayerCharacterSurvival.BP_IcarusPlayerCharacterSurvival_C.GetBPIcarusPlayerController");
		SetItem = FindObject<UE4::UFunction>("Function Icarus.Inventory.SetItem");
		RemoveItem = FindObject<UE4::UFunction>("Function Icarus.Inventory.RemoveItem"); 
		ActivateHotbarSlot = FindObject<UE4::UFunction>("Function Icarus.IcarusPlayerControllerSurvival.ActivateHotbarSlot"); 
		InpActEvt_HotbarForward_K2Node_InputActionEvent_5 = FindObject<UE4::UFunction>("Function BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C.InpActEvt_HotbarForward_K2Node_InputActionEvent_5");
		SetFocusedSlot = FindObject<UE4::UFunction>("Function BP_IcarusPlayerCharacterSurvival.BP_IcarusPlayerCharacterSurvival_C.SetFocusedSlot");
	}
	else if (Actor->GetClass()->GetFullName() == "BlueprintGeneratedClass BP_IcarusPlayerCharacterSurvival.BP_IcarusPlayerCharacterSurvival_C")
	{
		BP_IcarusPlayerCharacterSurvival_C = Actor;
	}
} 

void ExampleMod::PostBeginPlay(std::wstring ModActorName, UE4::AActor* Actor)
{
	// Filters Out All Mod Actors Not Related To Your Mod
	std::wstring TmpModName(ModName.begin(), ModName.end());
	if (ModActorName == TmpModName)
	{
		//Sets ModActor Ref
		ModActor = Actor;
	}
}
void ExampleMod::DX11Present(ID3D11Device* pDevice, ID3D11DeviceContext* pContext, ID3D11RenderTargetView* pRenderTargetView)
{
}

int index = 0;

void ExampleMod::OnModMenuButtonPressed()
{
}

void ExampleMod::DrawImGui()
{
}