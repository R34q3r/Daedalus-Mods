#include "ExampleMod.h"
#include "Utilities/MinHook.h"
#include "Ue4.hpp"

enum class EDynamicItemProperties : uint8_t {
	AssociatedItemInventoryId = 0,
	AssociatedItemInventorySlot = 1,
	DynamicState = 2,
	GunCurrentMagSize = 3,
	CurrentAmmoType = 4,
	BuildingVariation = 5,
	Durability = 6,
	ItemableStack = 7,
	MillijoulesRemaining = 8,
	TransmutableUnits = 9,
	Fillable_StoredUnits = 10,
	Fillable_Type = 11,
	Decayable_CurrentSpoilTime = 12,
	InventoryContainer_LinkedInventoryId = 13,
	MaxDynamicItemProperties = 14,
	EDynamicItemProperties_MAX = 15
};

enum class ELineDrawMethod : uint8_t {
	Unspecified = 0,
	NoLine = 1,
	ShortestDistance = 2,
	XThenY = 3,
	YThenX = 4,
	ELineDrawMethod_MAX = 5
};

enum class EFlagsTableType : uint8_t {
	D_CharacterFlags = 0,
	D_SessionFlags = 1,
	D_AccountFlags = 2,
	None = 255,
	EFlagsTableType_MAX = 256
};

struct FIntEnum {
	char pad_0[0x8]; // 0x00(0x08)
	struct UE4::FName Value; // 0x08(0x08)
};

struct FRowEnum : FIntEnum {
};

struct FInventoryIDEnum : FRowEnum {
};

struct FStatsEnum : FRowEnum {
};

struct FAlterationsEnum : FRowEnum {
};

struct FTableRowBase {
	char pad_0[0x8]; // 0x00(0x08)
};

struct FIcarusTableRowBase : FTableRowBase {
	struct UE4::TArray<struct UE4::UObject*> CachedHardReferences; // 0x08(0x10)
};

struct FItemDynamicData : FIcarusTableRowBase {
	enum class EDynamicItemProperties PropertyType; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	int32_t Value; // 0x1c(0x04)
};

struct FRowHandleInternal {
	char pad_0[0x1]; // 0x00(0x01)
};

struct FRowHandle : FRowHandleInternal {
	int32_t DataTablePtr; // 0x00(0x08)
	struct UE4::FName RowName; // 0x08(0x08)
	struct UE4::FName DataTableName; // 0x10(0x08)
};

struct FItemsStaticRowHandle : FRowHandle {
};

struct FTagQueriesRowHandle : FRowHandle {
};

struct FIcarusStatReplicated {
	struct FStatsEnum Stat; // 0x00(0x10)
	int32_t Value; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

struct FCustomProperties {
	struct UE4::TArray<struct FIcarusStatReplicated> StaticWorldStats; // 0x00(0x10)
	struct UE4::TArray<struct FIcarusStatReplicated> StaticWorldHeldStats; // 0x10(0x10)
	struct UE4::TArray<struct FIcarusStatReplicated> Stats; // 0x20(0x10)
	struct UE4::TArray<struct FAlterationsEnum> Alterations; // 0x30(0x10)
};

struct FGameplayTag {
	struct UE4::FName TagName; // 0x00(0x08)
};

struct FGameplayTagContainer {
	struct UE4::TArray<struct FGameplayTag> GameplayTags; // 0x00(0x10)
	struct UE4::TArray<struct FGameplayTag> ParentTags; // 0x10(0x10)
};

struct FItemData : FIcarusTableRowBase {
	struct FItemsStaticRowHandle ItemStaticData; // 0x18(0x18)
	struct UE4::TArray<struct FItemDynamicData> ItemDynamicData; // 0x30(0x10)
	struct FCustomProperties CustomProperties; // 0x40(0x40)
	struct UE4::FString DatabaseGUID; // 0x80(0x10)
	struct FGameplayTagContainer RuntimeTags; // 0x90(0x20)
};

struct FFastArraySerializerItem {
	int32_t ReplicationID; // 0x00(0x04)
	int32_t ReplicationKey; // 0x04(0x04)
	int32_t MostRecentArrayReplicationKey; // 0x08(0x04)
};

struct FInventorySlot : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct FItemData ItemData; // 0x10(0xb0)
	struct FTagQueriesRowHandle Query; // 0xc0(0x18)
	bool Locked; // 0xd8(0x01)
	char pad_D9[0x3]; // 0xd9(0x03)
	struct FItemsStaticRowHandle LastItem; // 0xdc(0x18)
	bool Slotable; // 0xf4(0x01)
	char pad_F5[0x3]; // 0xf5(0x03)
	int32_t Index; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
};

struct FStat {
	int32_t Type; // 0x00(0x04)
	int32_t Value; // 0x04(0x04)
};

struct FDynamicProperty {
	int32_t Type; // 0x00(0x04)
	int32_t Value; // 0x04(0x04)
};

struct FMetaItem {
	struct UE4::FString ItemStaticRow; // 0x00(0x10)
	struct UE4::TArray<struct FDynamicProperty> Properties; // 0x10(0x10)
	struct UE4::TArray<struct FStat> Stats; // 0x20(0x10)
	struct UE4::FString ID; // 0x30(0x10)
};

struct FItemTemplateRowHandle : FRowHandle {
};

struct FTalentRanksRowHandle : FRowHandle {
};

struct FMetaCurrencyRowHandle : FRowHandle {
};

struct FTalentsRowHandle : FRowHandle {
};

struct FTalentTreesRowHandle : FRowHandle {
};

struct FCharacterFlagsRowHandle : FRowHandle {
};

struct FMultiRowHandle {
	char pad_0[0x8]; // 0x00(0x08)
	struct UE4::FName RowName; // 0x08(0x08)
};

struct FFlagsMultiRowHandle : FMultiRowHandle {
	enum class EFlagsTableType DataTableName; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

struct FWorkshopCost {
	struct FMetaCurrencyRowHandle Meta; // 0x00(0x18)
	int32_t Amount; // 0x18(0x04)
};

struct FWorkshopItem : FIcarusTableRowBase {
	struct FItemTemplateRowHandle Item; // 0x18(0x18)
	struct UE4::TArray<struct FWorkshopCost> ResearchCost; // 0x30(0x10)
	struct UE4::TArray<struct FWorkshopCost> ReplicationCost; // 0x40(0x10)
	struct FTalentsRowHandle RequiredMission; // 0x50(0x18)
};

struct FBaseStatsEnum : FStatsEnum {
};

struct FTalentReward {
	struct UE4::TMap<struct FBaseStatsEnum, int32_t> GrantedStats; // 0x00(0x50)
	struct UE4::TArray<struct FCharacterFlagsRowHandle> GrantedFlags; // 0x50(0x10)
};

struct FTalent : FIcarusTableRowBase {
	bool bIsReroute; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct UE4::FText DisplayName; // 0x20(0x18)
	struct UE4::FText Description; // 0x38(0x18)
	int32_t Icon; // 0x50(0x28)
	struct FRowHandle ExtraData; // 0x78(0x18)
	struct FTalentTreesRowHandle TalentTree; // 0x90(0x18)
	struct UE4::FVector2D position; // 0xa8(0x08)
	struct UE4::FVector2D Size; // 0xb0(0x08)
	struct UE4::TArray<struct FTalentReward> Rewards; // 0xb8(0x10)
	struct UE4::TArray<struct FTalentsRowHandle> RequiredTalents; // 0xc8(0x10)
	struct UE4::TArray<struct FFlagsMultiRowHandle> RequiredFlags; // 0xd8(0x10)
	struct UE4::TArray<struct FFlagsMultiRowHandle> ForbiddenFlags; // 0xe8(0x10)
	struct FTalentRanksRowHandle RequiredRank; // 0xf8(0x18)
	int32_t RequiredLevel; // 0x110(0x04)
	bool bDefaultUnlocked; // 0x114(0x01)
	enum class ELineDrawMethod DrawMethodOverride; // 0x115(0x01)
	char pad_116[0x1a]; // 0x116(0x1a)
};

struct FLinearColor {
	float R; // 0x00(0x04)
	float G; // 0x04(0x04)
	float B; // 0x08(0x04)
	float A; // 0x0c(0x04)
};

struct UVisual : UE4::UObject {
};

struct FWidgetTransform {
	struct UE4::FVector2D Translation; // 0x00(0x08)
	struct UE4::FVector2D Scale; // 0x08(0x08)
	struct UE4::FVector2D Shear; // 0x10(0x08)
	float Angle; // 0x18(0x04)
};

enum class EMouseCursor : uint8_t {
	None = 0,
	Default = 1,
	TextEditBeam = 2,
	ResizeLeftRight = 3,
	ResizeUpDown = 4,
	ResizeSouthEast = 5,
	ResizeSouthWest = 6,
	CardinalCross = 7,
	Crosshairs = 8,
	Hand = 9,
	GrabHand = 10,
	GrabHandClosed = 11,
	SlashedCircle = 12,
	EyeDropper = 13,
	EMouseCursor_MAX = 14
};

enum class EWidgetClipping : uint8_t {
	Inherit = 0,
	ClipToBounds = 1,
	ClipToBoundsWithoutIntersecting = 2,
	ClipToBoundsAlways = 3,
	OnDemand = 4,
	EWidgetClipping_MAX = 5
};

enum class ESlateVisibility : uint8_t {
	Visible = 0,
	Collapsed = 1,
	Hidden = 2,
	HitTestInvisible = 3,
	SelfHitTestInvisible = 4,
	ESlateVisibility_MAX = 5
};

enum class EFlowDirectionPreference : uint8_t {
	Inherit = 0,
	Culture = 1,
	LeftToRight = 2,
	RightToLeft = 3,
	EFlowDirectionPreference_MAX = 4
};

struct FPropertyPathSegment {
	struct UE4::FName Name; // 0x00(0x08)
	int32_t ArrayIndex; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct UE4::UStruct* Struct; // 0x10(0x08)
	char pad_18[0x10]; // 0x18(0x10)
};

struct FCachedPropertyPath {
	struct UE4::TArray<struct FPropertyPathSegment> Segments; // 0x00(0x10)
	char pad_10[0x8]; // 0x10(0x08)
	struct UFunction* CachedFunction; // 0x18(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

struct FDynamicPropertyPath : FCachedPropertyPath {
};

struct UPropertyBinding : UE4::UObject {
	int32_t SourceObject; // 0x28(0x08)
	struct FDynamicPropertyPath SourcePath; // 0x30(0x28)
	struct UE4::FName DestinationProperty; // 0x58(0x08)
};

struct UWidget : UVisual {
	struct UPanelSlot* Slot; // 0x28(0x08)
	struct FDelegate* bIsEnabledDelegate; // 0x30(0x10)
	struct UE4::FText ToolTipText; // 0x40(0x18)
	struct FDelegate* ToolTipTextDelegate; // 0x58(0x10)
	struct UWidget* ToolTipWidget; // 0x68(0x08)
	struct FDelegate* ToolTipWidgetDelegate; // 0x70(0x10)
	struct FDelegate* VisibilityDelegate; // 0x80(0x10)
	struct FWidgetTransform RenderTransform; // 0x90(0x1c)
	struct UE4::FVector2D RenderTransformPivot; // 0xac(0x08)
	char bIsVariable : 1; // 0xb4(0x01)
	char bCreatedByConstructionScript : 1; // 0xb4(0x01)
	char bIsEnabled : 1; // 0xb4(0x01)
	char bOverride_Cursor : 1; // 0xb4(0x01)
	char pad_B4_4 : 4; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	struct USlateAccessibleWidgetData* AccessibleWidgetData; // 0xb8(0x08)
	char bIsVolatile : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	enum class EMouseCursor Cursor; // 0xc1(0x01)
	enum class EWidgetClipping Clipping; // 0xc2(0x01)
	enum class ESlateVisibility Visibility; // 0xc3(0x01)
	float RenderOpacity; // 0xc4(0x04)
	struct UWidgetNavigation* Navigation; // 0xc8(0x08)
	enum class EFlowDirectionPreference FlowDirectionPreference; // 0xd0(0x01)
	char pad_D1[0x27]; // 0xd1(0x27)
	struct UE4::TArray<struct UPropertyBinding*> NativeBindings; // 0xf8(0x10)

	void SetVisibility(enum class ESlateVisibility InVisibility); // Function UMG.Widget.SetVisibility // (Native|Public|BlueprintCallable) // @ game+0x30608b0
	void SetUserFocus(struct APlayerController* PlayerController); // Function UMG.Widget.SetUserFocus // (Final|Native|Public|BlueprintCallable) // @ game+0x3060680
	void SetToolTipText(struct FText& InToolTipText); // Function UMG.Widget.SetToolTipText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x30605b0
	void SetToolTip(struct UWidget* Widget); // Function UMG.Widget.SetToolTip // (Final|Native|Public|BlueprintCallable) // @ game+0x3060520
	void SetRenderTranslation(struct FVector2D Translation); // Function UMG.Widget.SetRenderTranslation // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3060410
	void SetRenderTransformPivot(struct FVector2D Pivot); // Function UMG.Widget.SetRenderTransformPivot // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3060390
	void SetRenderTransformAngle(float Angle); // Function UMG.Widget.SetRenderTransformAngle // (Final|Native|Public|BlueprintCallable) // @ game+0x3060310
	void SetRenderTransform(struct FWidgetTransform InTransform); // Function UMG.Widget.SetRenderTransform // (Final|Native|Public|BlueprintCallable) // @ game+0x3060230
	void SetRenderShear(struct FVector2D Shear); // Function UMG.Widget.SetRenderShear // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x30601b0
	void SetRenderScale(struct FVector2D Scale); // Function UMG.Widget.SetRenderScale // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3060130
	void SetRenderOpacity(float InOpacity); // Function UMG.Widget.SetRenderOpacity // (Final|Native|Public|BlueprintCallable) // @ game+0x30600b0
	void SetNavigationRuleExplicit(enum class EUINavigation Direction, struct UWidget* InWidget); // Function UMG.Widget.SetNavigationRuleExplicit // (Final|Native|Public|BlueprintCallable) // @ game+0x305ff50
	void SetNavigationRuleCustomBoundary(enum class EUINavigation Direction, struct FDelegate InCustomDelegate); // Function UMG.Widget.SetNavigationRuleCustomBoundary // (Final|Native|Public|BlueprintCallable) // @ game+0x305fe60
	void SetNavigationRuleCustom(enum class EUINavigation Direction, struct FDelegate InCustomDelegate); // Function UMG.Widget.SetNavigationRuleCustom // (Final|Native|Public|BlueprintCallable) // @ game+0x305fd70
	void SetNavigationRuleBase(enum class EUINavigation Direction, enum class EUINavigationRule Rule); // Function UMG.Widget.SetNavigationRuleBase // (Final|Native|Public|BlueprintCallable) // @ game+0x305fca0
	void SetNavigationRule(enum class EUINavigation Direction, enum class EUINavigationRule Rule, struct FName WidgetToFocus); // Function UMG.Widget.SetNavigationRule // (Final|Native|Public|BlueprintCallable) // @ game+0x305fb90
	void SetKeyboardFocus(); // Function UMG.Widget.SetKeyboardFocus // (Final|Native|Public|BlueprintCallable) // @ game+0x305fb70
	void SetIsEnabled(bool bInIsEnabled); // Function UMG.Widget.SetIsEnabled // (Native|Public|BlueprintCallable) // @ game+0x305fae0
	void SetFocus(); // Function UMG.Widget.SetFocus // (Final|Native|Public|BlueprintCallable) // @ game+0x305fa40
	void SetCursor(enum class EMouseCursor InCursor); // Function UMG.Widget.SetCursor // (Final|Native|Public|BlueprintCallable) // @ game+0x305f9c0
	void SetClipping(enum class EWidgetClipping InClipping); // Function UMG.Widget.SetClipping // (Final|Native|Public|BlueprintCallable) // @ game+0x305f940
	void SetAllNavigationRules(enum class EUINavigationRule Rule, struct FName WidgetToFocus); // Function UMG.Widget.SetAllNavigationRules // (Final|Native|Public|BlueprintCallable) // @ game+0x305f870
	void ResetCursor(); // Function UMG.Widget.ResetCursor // (Final|Native|Public|BlueprintCallable) // @ game+0x305f850
	void RemoveFromParent(); // Function UMG.Widget.RemoveFromParent // (Native|Public|BlueprintCallable) // @ game+0x305f830
	struct FEventReply OnReply__DelegateSignature(); // DelegateFunction UMG.Widget.OnReply__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	struct FEventReply OnPointerEvent__DelegateSignature(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // DelegateFunction UMG.Widget.OnPointerEvent__DelegateSignature // (Public|Delegate|HasOutParms) // @ game+0x1d780a0
	bool IsVisible(); // Function UMG.Widget.IsVisible // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f800
	bool IsHovered(); // Function UMG.Widget.IsHovered // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf390
	void InvalidateLayoutAndVolatility(); // Function UMG.Widget.InvalidateLayoutAndVolatility // (Final|Native|Public|BlueprintCallable) // @ game+0x305f7e0
	bool HasUserFocusedDescendants(struct APlayerController* PlayerController); // Function UMG.Widget.HasUserFocusedDescendants // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f740
	bool HasUserFocus(struct APlayerController* PlayerController); // Function UMG.Widget.HasUserFocus // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f6a0
	bool HasMouseCaptureByUser(int32_t UserIndex, int32_t PointerIndex); // Function UMG.Widget.HasMouseCaptureByUser // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f5d0
	bool HasMouseCapture(); // Function UMG.Widget.HasMouseCapture // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f5a0
	bool HasKeyboardFocus(); // Function UMG.Widget.HasKeyboardFocus // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f570
	bool HasFocusedDescendants(); // Function UMG.Widget.HasFocusedDescendants // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f540
	bool HasAnyUserFocus(); // Function UMG.Widget.HasAnyUserFocus // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f510
	struct UWidget* GetWidget__DelegateSignature(); // DelegateFunction UMG.Widget.GetWidget__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	enum class ESlateVisibility GetVisibility(); // Function UMG.Widget.GetVisibility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f4e0
	struct FGeometry GetTickSpaceGeometry(); // Function UMG.Widget.GetTickSpaceGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f3c0
	struct FText GetText__DelegateSignature(); // DelegateFunction UMG.Widget.GetText__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	enum class ESlateVisibility GetSlateVisibility__DelegateSignature(); // DelegateFunction UMG.Widget.GetSlateVisibility__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	struct FSlateColor GetSlateColor__DelegateSignature(); // DelegateFunction UMG.Widget.GetSlateColor__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	struct FSlateBrush GetSlateBrush__DelegateSignature(); // DelegateFunction UMG.Widget.GetSlateBrush__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	float GetRenderTransformAngle(); // Function UMG.Widget.GetRenderTransformAngle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f360
	float GetRenderOpacity(); // Function UMG.Widget.GetRenderOpacity // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f330
	struct UPanelWidget* GetParent(); // Function UMG.Widget.GetParent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f300
	struct FGeometry GetPaintSpaceGeometry(); // Function UMG.Widget.GetPaintSpaceGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f2c0
	struct APlayerController* GetOwningPlayer(); // Function UMG.Widget.GetOwningPlayer // (BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f290
	struct ULocalPlayer* GetOwningLocalPlayer(); // Function UMG.Widget.GetOwningLocalPlayer // (BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f260
	enum class EMouseCursor GetMouseCursor__DelegateSignature(); // DelegateFunction UMG.Widget.GetMouseCursor__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	struct FLinearColor GetLinearColor__DelegateSignature(); // DelegateFunction UMG.Widget.GetLinearColor__DelegateSignature // (Public|Delegate|HasDefaults) // @ game+0x1d780a0
	bool GetIsEnabled(); // Function UMG.Widget.GetIsEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f230
	int32_t GetInt32__DelegateSignature(); // DelegateFunction UMG.Widget.GetInt32__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	struct UGameInstance* GetGameInstance(); // Function UMG.Widget.GetGameInstance // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f200
	float GetFloat__DelegateSignature(); // DelegateFunction UMG.Widget.GetFloat__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	struct FVector2D GetDesiredSize(); // Function UMG.Widget.GetDesiredSize // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f190
	enum class EWidgetClipping GetClipping(); // Function UMG.Widget.GetClipping // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f160
	enum class ECheckBoxState GetCheckBoxState__DelegateSignature(); // DelegateFunction UMG.Widget.GetCheckBoxState__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	struct FGeometry GetCachedGeometry(); // Function UMG.Widget.GetCachedGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f120
	bool GetBool__DelegateSignature(); // DelegateFunction UMG.Widget.GetBool__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	struct FText GetAccessibleText(); // Function UMG.Widget.GetAccessibleText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305f080
	struct FText GetAccessibleSummaryText(); // Function UMG.Widget.GetAccessibleSummaryText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x305efe0
	struct UWidget* GenerateWidgetForString__DelegateSignature(struct FString Item); // DelegateFunction UMG.Widget.GenerateWidgetForString__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	struct UWidget* GenerateWidgetForObject__DelegateSignature(struct UObject* Item); // DelegateFunction UMG.Widget.GenerateWidgetForObject__DelegateSignature // (Public|Delegate) // @ game+0x1d780a0
	void ForceVolatile(bool bForce); // Function UMG.Widget.ForceVolatile // (Final|Native|Public|BlueprintCallable) // @ game+0x305ef50
	void ForceLayoutPrepass(); // Function UMG.Widget.ForceLayoutPrepass // (Final|Native|Public|BlueprintCallable) // @ game+0x305ef30
};

struct FInputActionKeyMapping {
	struct UE4::FName ActionName; // 0x00(0x08)
	char bShift : 1; // 0x08(0x01)
	char bCtrl : 1; // 0x08(0x01)
	char bAlt : 1; // 0x08(0x01)
	char bCmd : 1; // 0x08(0x01)
	char pad_8_4 : 4; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct UE4::FKey Key; // 0x10(0x18)
};