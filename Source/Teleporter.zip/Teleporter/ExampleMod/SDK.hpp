#include "Teleporter.h"
#include "Utilities/MinHook.h"
#include "Ue4.hpp"

struct FTableRowBase {
	char pad_0[0x8]; // 0x00(0x08)
};

struct FIcarusTableRowBase : FTableRowBase {
	struct UE4::TArray<struct UE4::UObject*> CachedHardReferences; // 0x08(0x10)
};

struct FRowHandleInternal {
	char pad_0[0x1]; // 0x00(0x01)
};

struct FRowHandle : FRowHandleInternal {
	int32_t DataTablePtr; // 0x00(0x08)
	struct UE4::FName RowName; // 0x08(0x08)
	struct UE4::FName DataTableName; // 0x10(0x08)
};

struct FItemsStaticRowHandle : FRowHandle {
};

enum class EDynamicItemProperties : uint8_t {
	AssociatedItemInventoryId = 0,
	AssociatedItemInventorySlot = 1,
	DynamicState = 2,
	GunCurrentMagSize = 3,
	CurrentAmmoType = 4,
	BuildingVariation = 5,
	Durability = 6,
	ItemableStack = 7,
	MillijoulesRemaining = 8,
	TransmutableUnits = 9,
	Fillable_StoredUnits = 10,
	Fillable_Type = 11,
	Decayable_CurrentSpoilTime = 12,
	InventoryContainer_LinkedInventoryId = 13,
	MaxDynamicItemProperties = 14,
	EDynamicItemProperties_MAX = 15
};

struct FItemDynamicData : FIcarusTableRowBase {
	enum class EDynamicItemProperties PropertyType; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	int32_t Value; // 0x1c(0x04)
};

struct FIntEnum {
	char pad_0[0x8]; // 0x00(0x08)
	struct UE4::FName Value; // 0x08(0x08)
};

struct FRowEnum : FIntEnum {
};

struct FStatsEnum : FRowEnum {
};

struct FIcarusStatReplicated {
	struct FStatsEnum Stat; // 0x00(0x10)
	int32_t Value; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

struct FAlterationsEnum : FRowEnum {
};

struct FCustomProperties {
	struct UE4::TArray<struct FIcarusStatReplicated> StaticWorldStats; // 0x00(0x10)
	struct UE4::TArray<struct FIcarusStatReplicated> StaticWorldHeldStats; // 0x10(0x10)
	struct UE4::TArray<struct FIcarusStatReplicated> Stats; // 0x20(0x10)
	struct UE4::TArray<struct FAlterationsEnum> Alterations; // 0x30(0x10)
};

struct FGameplayTag {
	struct UE4::FName TagName; // 0x00(0x08)
};

struct FGameplayTagContainer {
	struct UE4::TArray<struct FGameplayTag> GameplayTags; // 0x00(0x10)
	struct UE4::TArray<struct FGameplayTag> ParentTags; // 0x10(0x10)
};

struct FItemData : FIcarusTableRowBase {
	struct FItemsStaticRowHandle ItemStaticData; // 0x18(0x18)
	struct UE4::TArray<struct FItemDynamicData> ItemDynamicData; // 0x30(0x10)
	struct FCustomProperties CustomProperties; // 0x40(0x40)
	struct UE4::FString DatabaseGUID; // 0x80(0x10)
	struct FGameplayTagContainer RuntimeTags; // 0x90(0x20)
};

struct FFastArraySerializerItem {
	int32_t ReplicationID; // 0x00(0x04)
	int32_t ReplicationKey; // 0x04(0x04)
	int32_t MostRecentArrayReplicationKey; // 0x08(0x04)
};

struct FTagQueriesRowHandle : FRowHandle {
};

struct FDynamicProperty {
	int32_t Type; // 0x00(0x04)
	int32_t Value; // 0x04(0x04)
};

struct FInventoryIDEnum : FRowEnum {
};

struct FMetaItem {
	struct UE4::FString ItemStaticRow; // 0x00(0x10)
	struct UE4::TArray<struct FDynamicProperty> Properties; // 0x10(0x10)
	struct UE4::TArray<struct FStat> Stats; // 0x20(0x10)
	struct UE4::FString ID; // 0x30(0x10)
};

struct FInventorySlot : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct FItemData ItemData; // 0x10(0xb0)
	struct FTagQueriesRowHandle Query; // 0xc0(0x18)
	bool Locked; // 0xd8(0x01)
	char pad_D9[0x3]; // 0xd9(0x03)
	struct FItemsStaticRowHandle LastItem; // 0xdc(0x18)
	bool Slotable; // 0xf4(0x01)
	char pad_F5[0x3]; // 0xf5(0x03)
	int32_t Index; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
};

struct FItemTemplateRowHandle : FRowHandle {
};

struct FTalentTreesRowHandle : FRowHandle {
};

struct FBaseStatsEnum : FStatsEnum {
};

struct FCharacterFlagsRowHandle : FRowHandle {
};

struct FTalentReward {
	struct UE4::TMap<struct FBaseStatsEnum, int32_t> GrantedStats; // 0x00(0x50)
	struct UE4::TArray<struct FCharacterFlagsRowHandle> GrantedFlags; // 0x50(0x10)
};

struct FTalentsRowHandle : FRowHandle {
};

enum class EFlagsTableType : uint8_t {
	D_CharacterFlags = 0,
	D_SessionFlags = 1,
	D_AccountFlags = 2,
	None = 255,
	EFlagsTableType_MAX = 256
};

struct FMultiRowHandle {
	char pad_0[0x8]; // 0x00(0x08)
	struct UE4::FName RowName; // 0x08(0x08)
};

struct FFlagsMultiRowHandle : FMultiRowHandle {
	enum class EFlagsTableType DataTableName; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

struct FTalentRanksRowHandle : FRowHandle {
};

enum class ELineDrawMethod : uint8_t {
	Unspecified = 0,
	NoLine = 1,
	ShortestDistance = 2,
	XThenY = 3,
	YThenX = 4,
	ELineDrawMethod_MAX = 5
};

struct FTalent : FIcarusTableRowBase {
	bool bIsReroute; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct UE4::FText DisplayName; // 0x20(0x18)
	struct UE4::FText Description; // 0x38(0x18)
	int32_t Icon; // 0x50(0x28)
	struct FRowHandle ExtraData; // 0x78(0x18)
	struct FTalentTreesRowHandle TalentTree; // 0x90(0x18)
	struct UE4::FVector2D position; // 0xa8(0x08)
	struct UE4::FVector2D Size; // 0xb0(0x08)
	struct UE4::TArray<struct FTalentReward> Rewards; // 0xb8(0x10)
	struct UE4::TArray<struct FTalentsRowHandle> RequiredTalents; // 0xc8(0x10)
	struct UE4::TArray<struct FFlagsMultiRowHandle> RequiredFlags; // 0xd8(0x10)
	struct UE4::TArray<struct FFlagsMultiRowHandle> ForbiddenFlags; // 0xe8(0x10)
	struct FTalentRanksRowHandle RequiredRank; // 0xf8(0x18)
	int32_t RequiredLevel; // 0x110(0x04)
	bool bDefaultUnlocked; // 0x114(0x01)
	enum class ELineDrawMethod DrawMethodOverride; // 0x115(0x01)
	char pad_116[0x1a]; // 0x116(0x1a)
};

enum class EProspectLocation : uint8_t {
	Unknown = 0,
	Hab = 1,
	Prospect_Conifer = 2,
	Prospect_Arctic = 3,
	Prospect_Cave = 4,
	Prospect_Desert = 5,
	EProspectLocation_MAX = 6
};

struct FAssociatedMemberInfo {
	struct UE4::FString AccountName; // 0x00(0x10)
	struct UE4::FString CharacterName; // 0x10(0x10)
	struct UE4::FString UserID; // 0x20(0x10)
	int32_t ChrSlot; // 0x30(0x04)
	int32_t Experience; // 0x34(0x04)
	enum class EProspectLocation Status; // 0x38(0x01)
	bool Settled; // 0x39(0x01)
	bool IsCurrentlyPlaying; // 0x3a(0x01)
	char pad_3B[0x5]; // 0x3b(0x05)
};

enum class EProspectState : uint8_t {
	Unclaimed = 0,
	Claimed = 1,
	Active = 2,
	Ended = 3,
	MaxProspectStates = 4,
	EProspectState_MAX = 5
};

enum class EMissionDifficulty : uint8_t {
	None = 0,
	Easy = 1,
	Medium = 2,
	Hard = 3,
	Extreme = 4,
	EMissionDifficulty_MAX = 5
};

struct FProspectInfo {
	struct UE4::FString ProspectID; // 0x00(0x10)
	struct UE4::FString ClaimedAccountID; // 0x10(0x10)
	int32_t ClaimedAccountCharacter; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct UE4::FString ProspectDTKey; // 0x28(0x10)
	struct UE4::FString FactionMissionDTKey; // 0x38(0x10)
	struct UE4::FString LobbyName; // 0x48(0x10)
	int64_t ExpireTime; // 0x58(0x08)
	enum class EProspectState ProspectState; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct UE4::TArray<struct FAssociatedMemberInfo> AssociatedMembers; // 0x68(0x10)
	int32_t Cost; // 0x78(0x04)
	int32_t Reward; // 0x7c(0x04)
	enum class EMissionDifficulty Difficulty; // 0x80(0x01)
	bool Insurance; // 0x81(0x01)
	bool NoRespawns; // 0x82(0x01)
	char pad_83[0x1]; // 0x83(0x01)
	int32_t ElapsedTime; // 0x84(0x04)
};

enum class ETickingGroup : uint8_t {
	TG_PrePhysics = 0,
	TG_StartPhysics = 1,
	TG_DuringPhysics = 2,
	TG_EndPhysics = 3,
	TG_PostPhysics = 4,
	TG_PostUpdateWork = 5,
	TG_LastDemotable = 6,
	TG_NewlySpawned = 7,
	TG_MAX = 8
};

struct FTickFunction {
	char pad_0[0x8]; // 0x00(0x08)
	enum class ETickingGroup TickGroup; // 0x08(0x01)
	enum class ETickingGroup EndTickGroup; // 0x09(0x01)
	char bTickEvenWhenPaused : 1; // 0x0a(0x01)
	char bCanEverTick : 1; // 0x0a(0x01)
	char bStartWithTickEnabled : 1; // 0x0a(0x01)
	char bAllowTickOnDedicatedServer : 1; // 0x0a(0x01)
	char pad_A_4 : 4; // 0x0a(0x01)
	char pad_B[0x1]; // 0x0b(0x01)
	float TickInterval; // 0x0c(0x04)
	char pad_10[0x18]; // 0x10(0x18)
};

struct FActorComponentTickFunction : FTickFunction {
	char pad_28[0x8]; // 0x28(0x08)
};

enum class EComponentCreationMethod : uint8_t {
	Native = 0,
	SimpleConstructionScript = 1,
	UserConstructionScript = 2,
	Instance = 3,
	EComponentCreationMethod_MAX = 4
};

struct FSimpleMemberReference {
	struct UE4::UObject* MemberParent; // 0x00(0x08)
	struct UE4::FName MemberName; // 0x08(0x08)
	struct UE4::FGuid MemberGuid; // 0x10(0x10)
};

struct UActorComponent : UE4::UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct UE4::TArray<struct UE4::FName> ComponentTags; // 0x60(0x10)
	struct UE4::TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	char pad_80[0x4]; // 0x80(0x04)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_88_0 : 3; // 0x88(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char pad_88_5 : 3; // 0x88(0x01)
	char pad_89_0 : 7; // 0x89(0x01)
	char bAutoActivate : 1; // 0x89(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_8A_2 : 1; // 0x8a(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_8A_4 : 1; // 0x8a(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	char pad_8A_6 : 2; // 0x8a(0x01)
	char pad_8B[0x1]; // 0x8b(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8c(0x01)
	char OnComponentActivated[0x1]; // 0x8b(0x01)
	char OnComponentDeactivated[0x1]; // 0x8b(0x01)
	char pad_8F[0x1]; // 0x8f(0x01)
	struct UE4::TArray<struct FSimpleMemberReference> UCSModifiedProperties; // 0x90(0x10)
	char pad_A0[0x10]; // 0xa0(0x10)
};

struct UTraitBehaviour : UActorComponent {
	struct UTraitBehaviours* OwningComponent; // 0xb0(0x08)
	bool bBehaviourDelegatesBound; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
};

enum class EFastArraySerializerDeltaFlags : uint8_t {
	None = 0,
	HasBeenSerialized = 1,
	HasDeltaBeenRequested = 2,
	IsUsingDeltaSerialization = 4,
	EFastArraySerializerDeltaFlags_MAX = 5
};

struct FFastArraySerializer {
	char pad_0[0x54]; // 0x00(0x54)
	int32_t ArrayReplicationKey; // 0x54(0x04)
	char pad_58[0xa8]; // 0x58(0xa8)
	enum class EFastArraySerializerDeltaFlags DeltaFlags; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
};

struct FInventorySlotsFastArray : FFastArraySerializer {
	struct UE4::TArray<struct FInventorySlot> Slots; // 0x108(0x10)
	char pad_118[0x40]; // 0x118(0x40)
};

struct FInventoryInfoRowHandle : FRowHandle {
};

struct UInventory : UTraitBehaviour {
	char OnInventoryItemChanged[0x10]; // 0xb9(0x07)
	char OnAllInventoryItemsChanged[0x10]; // 0xb9(0x07)
	int32_t CurrentWeight; // 0xe0(0x04)
	char pad_E4[0x4]; // 0xe4(0x04)
	struct FInventorySlotsFastArray Slots; // 0xe8(0x158)
	struct UE4::FTransform OverflowSpawnTransform; // 0x240(0x30)
	struct UE4::TArray<struct FItemData> InitialItems; // 0x270(0x10)
	char OnItemAdded[0x1]; // 0xe4(0x04)
	char OnItemRemoved[0x1]; // 0xe4(0x04)
	char OnItemRemovedVerbose[0x1]; // 0xe4(0x04)
	char Client_OnItemsUpdated[0x1]; // 0xe4(0x04)
	char OnWeightUpdated[0x1]; // 0xe4(0x04)
	char SlotCountChange[0x1]; // 0xe4(0x04)
	char SlotsUpdated[0x1]; // 0xe4(0x04)
	char OnDroppingOverflowItem[0x1]; // 0xe4(0x04)
	char OnItemBroke[0x1]; // 0xe4(0x04)
	char pad_289[0x3]; // 0x289(0x03)
	struct FInventoryInfoRowHandle InventoryInfoRowHandle; // 0x28c(0x18)
	char pad_2A4[0x1c]; // 0x2a4(0x1c)
};

enum class EMetaInventoryID : uint8_t {
	MetaInventoryID_UndefinedID = 0,
	MetaInventoryID_Main = 1,
	MetaInventoryID_DropLoadout = 2,
	MetaInventoryID_MAX = 3
};

struct FReqMoveMetaInventoryItem {
	struct UE4::FString UserID; // 0x00(0x10)
	int32_t CharacterSlot; // 0x10(0x04)
	enum class EMetaInventoryID SrcMetaInventoryID; // 0x14(0x01)
	enum class EMetaInventoryID DstMetaInventoryID; // 0x15(0x01)
	char pad_16[0x2]; // 0x16(0x02)
	struct UE4::FString ScrItemId; // 0x18(0x10)
	struct UE4::FString DstItemId; // 0x28(0x10)
	int32_t Count; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

enum class ESlateVisibility : uint8_t {
	Visible = 0,
	Collapsed = 1,
	Hidden = 2,
	HitTestInvisible = 3,
	SelfHitTestInvisible = 4,
	ESlateVisibility_MAX = 5
};

struct FMargin {
	float Left; // 0x00(0x04)
	float Top; // 0x04(0x04)
	float Right; // 0x08(0x04)
	float Bottom; // 0x0c(0x04)
};

struct FAnchors {
	struct UE4::FVector2D Minimum; // 0x00(0x08)
	struct UE4::FVector2D Maximum; // 0x08(0x08)
};

enum class ESlateColorStylingMode : uint8_t {
	UseColor_Specified = 0,
	UseColor_Specified_Link = 1,
	UseColor_Foreground = 2,
	UseColor_Foreground_Subdued = 3,
	UseColor_MAX = 4
};

struct FSlateColor {
	struct UE4::FLinearColor SpecifiedColor; // 0x00(0x10)
	enum class ESlateColorStylingMode ColorUseRule; // 0x10(0x01)
	char pad_11[0x17]; // 0x11(0x17)
};

struct FNamedSlotBinding {
	struct UE4::FName Name; // 0x00(0x08)
	struct UWidget* Content; // 0x08(0x08)
};

enum class EWidgetTickFrequency : uint8_t {
	Never = 0,
	Auto = 1,
	EWidgetTickFrequency_MAX = 2
};

enum class EWidgetAnimationEvent : uint8_t {
	Started = 0,
	Finished = 1,
	EWidgetAnimationEvent_MAX = 2
};

struct FAnimationEventBinding {
	struct UWidgetAnimation* Animation; // 0x00(0x08)
	char Delegate[0x10];
	enum class EWidgetAnimationEvent AnimationEvent; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	struct UE4::FName UserTag; // 0x1c(0x08)
	char pad_24[0x4]; // 0x24(0x04)
};

struct FWidgetTransform {
	struct UE4::FVector2D Translation; // 0x00(0x08)
	struct UE4::FVector2D Scale; // 0x08(0x08)
	struct UE4::FVector2D Shear; // 0x10(0x08)
	float Angle; // 0x18(0x04)
};

enum class EMouseCursor : uint8_t {
	None = 0,
	Default = 1,
	TextEditBeam = 2,
	ResizeLeftRight = 3,
	ResizeUpDown = 4,
	ResizeSouthEast = 5,
	ResizeSouthWest = 6,
	CardinalCross = 7,
	Crosshairs = 8,
	Hand = 9,
	GrabHand = 10,
	GrabHandClosed = 11,
	SlashedCircle = 12,
	EyeDropper = 13,
	EMouseCursor_MAX = 14
};

enum class EWidgetClipping : uint8_t {
	Inherit = 0,
	ClipToBounds = 1,
	ClipToBoundsWithoutIntersecting = 2,
	ClipToBoundsAlways = 3,
	OnDemand = 4,
	EWidgetClipping_MAX = 5
};

enum class EFlowDirectionPreference : uint8_t {
	Inherit = 0,
	Culture = 1,
	LeftToRight = 2,
	RightToLeft = 3,
	EFlowDirectionPreference_MAX = 4
};

struct UVisual : UE4::UObject {
};

struct UWidget : UVisual {
	struct UPanelSlot* Slot; // 0x28(0x08)
	char bIsEnabledDelegate[0x10];
	struct UE4::FText ToolTipText; // 0x40(0x18)
	char ToolTipTextDelegate[0x10];
	struct UWidget* ToolTipWidget; // 0x68(0x08)
	char ToolTipWidgetDelegate[0x10];
	char VisibilityDelegate[0x10];
	struct FWidgetTransform RenderTransform; // 0x90(0x1c)
	struct UE4::FVector2D RenderTransformPivot; // 0xac(0x08)
	char bIsVariable : 1; // 0xb4(0x01)
	char bCreatedByConstructionScript : 1; // 0xb4(0x01)
	char bIsEnabled : 1; // 0xb4(0x01)
	char bOverride_Cursor : 1; // 0xb4(0x01)
	char pad_B4_4 : 4; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	struct USlateAccessibleWidgetData* AccessibleWidgetData; // 0xb8(0x08)
	char bIsVolatile : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	enum class EMouseCursor Cursor; // 0xc1(0x01)
	enum class EWidgetClipping Clipping; // 0xc2(0x01)
	enum class ESlateVisibility Visibility; // 0xc3(0x01)
	float RenderOpacity; // 0xc4(0x04)
	struct UWidgetNavigation* Navigation; // 0xc8(0x08)
	enum class EFlowDirectionPreference FlowDirectionPreference; // 0xd0(0x01)
	char pad_D1[0x27]; // 0xd1(0x27)
	struct UE4::TArray<struct UPropertyBinding*> NativeBindings; // 0xf8(0x10)
};

struct UUserWidget : UWidget {
	char pad_108[0x8]; // 0x108(0x08)
	struct UE4::FLinearColor ColorAndOpacity; // 0x110(0x10)
	char ColorAndOpacityDelegate[0x10];
	struct FSlateColor ForegroundColor; // 0x130(0x28)
	char ForegroundColorDelegate[0x10];
	char OnVisibilityChanged[0x10];
	char pad_178[0x18]; // 0x178(0x18)
	struct FMargin Padding; // 0x190(0x10)
	struct UE4::TArray<struct UUMGSequencePlayer*> ActiveSequencePlayers; // 0x1a0(0x10)
	struct UUMGSequenceTickManager* AnimationTickManager; // 0x1b0(0x08)
	struct UE4::TArray<struct UUMGSequencePlayer*> StoppedSequencePlayers; // 0x1b8(0x10)
	struct UE4::TArray<struct FNamedSlotBinding> NamedSlotBindings; // 0x1c8(0x10)
	struct UWidgetTree* WidgetTree; // 0x1d8(0x08)
	int32_t Priority; // 0x1e0(0x04)
	char bSupportsKeyboardFocus : 1; // 0x1e4(0x01)
	char bIsFocusable : 1; // 0x1e4(0x01)
	char bStopAction : 1; // 0x1e4(0x01)
	char bHasScriptImplementedTick : 1; // 0x1e4(0x01)
	char bHasScriptImplementedPaint : 1; // 0x1e4(0x01)
	char pad_1E4_5 : 3; // 0x1e4(0x01)
	char pad_1E5[0xb]; // 0x1e5(0x0b)
	enum class EWidgetTickFrequency TickFrequency; // 0x1f0(0x01)
	char pad_1F1[0x7]; // 0x1f1(0x07)
	struct UInputComponent* InputComponent; // 0x1f8(0x08)
	struct UE4::TArray<struct FAnimationEventBinding> AnimationCallbacks; // 0x200(0x10)
	char pad_210[0x50]; // 0x210(0x50)
};

struct FMapIconsRowHandle : FRowHandle {
};

struct FMapIconsStruct {
	struct FMapIconsRowHandle MapIconRowHandle_21_5E78975746631601389008A28654463F; // 0x00(0x18)
	struct UE4::TArray<struct UUMG_IcarusLinkedActorPanel_C*> SpawnedWidgets_22_F5A77F6747E2C93B2ED6038A8AB5530E; // 0x18(0x10)
	bool ClientHideOption_24_D1E09926443050C60C81D191B78FF48C; // 0x28(0x01)
};

struct FTimerHandle {
	uint64_t Handle; // 0x00(0x08)
};

struct UIcarusLinkedActorPanelBase : UUserWidget {
};

struct UUMG_IcarusLinkedActorPanel_C : UIcarusLinkedActorPanelBase {
	char UberGraphFrame[0x08]; // 0x271(0x08)
	struct UE4::AActor* LinkedActor; // 0x268(0x08)
	bool AutoCloseAtDistance; // 0x270(0x01)
	char pad_271[0x3]; // 0x271(0x03)
	float AutoCloseDistance; // 0x274(0x04)
	struct FTimerHandle DistanceCheckTimer; // 0x278(0x08)
};

struct UUMG_RadarMainScreenBase_C : UUMG_IcarusLinkedActorPanel_C {
	bool DebugDisableFOW; // 0x280(0x01)
};

struct UUMG_RadarMainScreen_C : UUMG_RadarMainScreenBase_C {
	char pad_281[0x7]; // 0x281(0x07)
	char UberGraphFrame[0x8]; // 0x281(0x07)
	struct UUMG_ButtonIcon_C* ButtonMapCombined; // 0x290(0x08)
	struct UUMG_ButtonIcon_C* ButtonMapTopo; // 0x298(0x08)
	struct UUMG_ButtonIcon_C* ButtonMapVisual; // 0x2a0(0x08)
	struct UUMG_ButtonIcon_C* CenterMapButton; // 0x2a8(0x08)
	struct UCanvasPanel* DepositLocationsPanel; // 0x2b0(0x08)
	struct UImage* FOWImage; // 0x2b8(0x08)
	struct UImage* Image; // 0x2c0(0x08)
	struct UImage* Image_2; // 0x2c8(0x08)
	struct UImage* Image_3; // 0x2d0(0x08)
	struct UImage* Image_4; // 0x2d8(0x08)
	struct UImage* Image_5; // 0x2e0(0x08)
	struct UImage* Image_6; // 0x2e8(0x08)
	struct UImage* Image_7; // 0x2f0(0x08)
	struct UImage* Image_8; // 0x2f8(0x08)
	struct UImage* Image_9; // 0x300(0x08)
	struct UImage* Image_10; // 0x308(0x08)
	struct UImage* Image_11; // 0x310(0x08)
	struct UImage* Image_12; // 0x318(0x08)
	struct UImage* Image_13; // 0x320(0x08)
	struct UImage* Image_14; // 0x328(0x08)
	struct UImage* Image_547; // 0x330(0x08)
	struct UImage* Image_715; // 0x338(0x08)
	struct UImage* Image_730; // 0x340(0x08)
	struct UHorizontalBox* legendActiveArea; // 0x348(0x08)
	struct UHorizontalBox* legendBuilding; // 0x350(0x08)
	struct UHorizontalBox* LegendCompletedArea; // 0x358(0x08)
	struct UHorizontalBox* legendDowned; // 0x360(0x08)
	struct UHorizontalBox* legendDropship; // 0x368(0x08)
	struct UHorizontalBox* legendemptytiles; // 0x370(0x08)
	struct UHorizontalBox* legendgoodtiles; // 0x378(0x08)
	struct UImage* LegendGradientShadow; // 0x380(0x08)
	struct UImage* LegendGradientShadow_2; // 0x388(0x08)
	struct UHorizontalBox* legendMeta; // 0x390(0x08)
	struct UHorizontalBox* legendplayer; // 0x398(0x08)
	struct UHorizontalBox* legendRadar; // 0x3a0(0x08)
	struct UCanvasPanel* MapRadarCanvas; // 0x3a8(0x08)
	struct UCanvasPanel* MapSpaceCanvas_2; // 0x3b0(0x08)
	struct UUniformGridPanel* MapTileUniformGrid_Heightmap; // 0x3b8(0x08)
	struct UUniformGridPanel* MapTileUniformGrid_Visual; // 0x3c0(0x08)
	struct UScaleBox* MapZoomScaleBox; // 0x3c8(0x08)
	struct USizeBox* ObjectiveListSizeBox; // 0x3d0(0x08)
	struct UImage* OutOfBoundsImage; // 0x3d8(0x08)
	struct UImage* RadarHeatmapImage; // 0x3e0(0x08)
	struct UCanvasPanel* RadarLocationsPanel; // 0x3e8(0x08)
	struct URetainerBox* RetainerBox_191; // 0x3f0(0x08)
	struct UCanvasPanel* TileCanvas; // 0x3f8(0x08)
	struct UUMG_ButtonIcon_C* ToggleRadarButton; // 0x400(0x08)
	struct UCanvasPanel* TranslationCanvas; // 0x408(0x08)
	struct UImage* TranslationCanvasBackgroundcolor; // 0x410(0x08)
	struct UImage* TranslationCanvasBackgroundPattern; // 0x418(0x08)
	struct UUMG_BasicButton_2_C* UMG_BasicButton_CenterMap; // 0x420(0x08)
	struct UUMG_BasicButton_2_C* UMG_BasicButton_Combined; // 0x428(0x08)
	struct UUMG_BasicButton_2_C* UMG_BasicButton_ToggleRadar; // 0x430(0x08)
	struct UUMG_BasicButton_2_C* UMG_BasicButton_Topographical; // 0x438(0x08)
	struct UUMG_BasicButton_2_C* UMG_BasicButton_Visual; // 0x440(0x08)
	struct UUMG_ProspectObjectiveList_C* UMG_ProspectObjectiveList; // 0x448(0x08)
	struct UUMG_RadarMapGrid_C* UMG_RadarMapGrid; // 0x450(0x08)
	struct UE4::TArray<struct UUMG_IcarusLinkedActorPanel_C*> RadarLocationWidgets; // 0x458(0x10)
	struct UE4::TArray<struct UUMG_IcarusLinkedActorPanel_C*> DepositLocationWidgets; // 0x468(0x10)
	struct AMapManager_C* MapManager; // 0x478(0x08)
	struct UUMG_RadarIcon_C* debugmarker; // 0x480(0x08)
	struct UE4::TArray<struct UUMG_IcarusLinkedActorPanel_C*> PlayerLocationWidgets; // 0x488(0x10)
	struct UE4::TArray<struct UUMG_IcarusLinkedActorPanel_C*> UnsortedActorLocationWidgets; // 0x498(0x10)
	struct UE4::TArray<struct UUMG_RadarSquare_C*> ScannedRadarTiles; // 0x4a8(0x10)
	struct UE4::TArray<struct UUMG_RadarSquare_C*> RadarRadius; // 0x4b8(0x10)
	struct UE4::TArray<struct UUMG_RadarSquare_C*> OrphanedScannedRadarTiles; // 0x4c8(0x10)
	struct UE4::TArray<struct UUMG_IcarusLinkedActorPanel_C*> DropshipLocationWidgets; // 0x4d8(0x10)
	struct UE4::TArray<struct UUMG_IcarusLinkedActorPanel_C*> GraveLocationWidgets; // 0x4e8(0x10)
	struct UE4::TArray<struct UUMG_IcarusLinkedActorPanel_C*> GridLocationWidgets; // 0x4f8(0x10)
	struct UE4::TArray<struct UUMG_IcarusLinkedActorPanel_C*> WaypointLocationWidgets; // 0x508(0x10)
	struct UE4::TArray<struct UUMG_IcarusLinkedActorPanel_C*> EquipmentPodLocationsWidgets; // 0x518(0x10)
	float MapIconGlobalSizeMultiplier; // 0x528(0x04)
	float MapIconGlobalMinSizeClamp; // 0x52c(0x04)
	float MapIconGlobalMaxSizeClamp; // 0x530(0x04)
	float MapMaxZoomOut; // 0x534(0x04)
	float MapMaxZoomIn; // 0x538(0x04)
	char pad_53C[0x4]; // 0x53c(0x04)
	struct UE4::TArray<struct FMapIconsStruct> MapIconSettings; // 0x540(0x10)
	float FirstTimeOpenZoom; // 0x550(0x04)
	char pad_554[0x4]; // 0x554(0x04)
	struct UMaterialInstanceDynamic* RadarHeatmapMaskDMI; // 0x558(0x08)
	struct UMaterialInstanceDynamic* RadarHeatmapMetaLayerDMI; // 0x560(0x08)
	bool ShiftIsDown; // 0x568(0x01)
	bool CtrlIsDown; // 0x569(0x01)
	bool AltIsDown; // 0x56a(0x01)
	char pad_56B[0x1]; // 0x56b(0x01)
	int32_t V2ScansProcessed; // 0x56c(0x04)
	bool MapTickedOnce; // 0x570(0x01)
	char pad_571[0x3]; // 0x571(0x03)
	int32_t V3ScansProcessed; // 0x574(0x04)
	struct UE4::TArray<struct UUMG_RadarSquare_C*> RadarV3Radius; // 0x578(0x10)
	float MapZoomRateOfChange; // 0x588(0x04)
	char pad_58C[0x4]; // 0x58c(0x04)
	struct UE4::TMap<struct UObject*, struct UUMG_QuestWidget_C*> QuestWidgetMap; // 0x590(0x50)
	struct FSlateColor Purple; // 0x5e0(0x28)
	struct UE4::FVector ContextMenuCachedWorldLocation; // 0x608(0x0c)
	struct UE4::FVector MouseDownCachedWorldLocation; // 0x614(0x0c)
	bool DragOperationOccurred; // 0x620(0x01)
	char pad_621[0x3]; // 0x621(0x03)
	int32_t TileSize; // 0x624(0x04)
	struct UMaterialInstanceDynamic* FowMaskDMI; // 0x628(0x08)
	struct UObject* AsyncOOBImageCache; // 0x630(0x08)
	char FullBoundsGameplayTexture[0x28]; // 0x621(0x03)
	//struct TSoftObjectPtr<UGameplayTexture> FullBoundsGameplayTexture; // 0x638(0x28)
	struct UE4::TArray<struct UUMG_RadarSquare_C*> QuestCircles; // 0x660(0x10)
	float GameTimeOfLastTick; // 0x670(0x04)
	int32_t RenderCountThisFrame; // 0x674(0x04)
	float MapIconGlobalSizeMultiplierNew; // 0x678(0x04)
	char pad_67C[0x4]; // 0x67c(0x04)
	struct UE4::FText ContextMenuHeadingText; // 0x680(0x18)
	struct UE4::TArray<struct UE4::FVector> PendingFOWDrawLocations; // 0x698(0x10)
	int32_t NewVar_0_1; // 0x6a8(0x04)
	char pad_6AC[0x4]; // 0x6ac(0x04)
	struct UE4::TArray<struct UE4::FVector> OldFOWDrawLocations; // 0x6b0(0x10)
	bool NeedsUpdate; // 0x6c0(0x01)
};

struct UUMG_MainMap_C : UUserWidget {
	struct FPointerToUberGraphFrame* UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* MapDisabled; // 0x268(0x08)
	struct UVerticalBox* DisabledVbox; // 0x270(0x08)
	struct UImage* Image; // 0x278(0x08)
	struct UImage* Image_60; // 0x280(0x08)
	struct UHorizontalBox* Keyprompts; // 0x288(0x08)
	struct UBorder* MapDisabledBox; // 0x290(0x08)
	struct UUMG_RadarMainScreen_C* UMG_RadarMainScreen; // 0x298(0x08)
	struct UUMG_UserInterface_C* UserInterface; // 0x2a0(0x08)
	bool IsMapDisabled; // 0x2a8(0x01)
};

struct UUMG_ButtonIcon_C : UUserWidget {
	struct FPointerToUberGraphFrame* UberGraphFrame; // 0x260(0x08)
	struct UImage* Icon; // 0x268(0x08)
	struct UButton* ImageButton; // 0x270(0x08)
	struct USizeBox* SizeBox; // 0x278(0x08)
	char Clicked[0x4]; // 0x6ac(0x10)
	struct UFont* TextFont; // 0x290(0x08)
	struct FSlateColor Colour_Normal; // 0x298(0x28)
	struct FSlateColor Colour_Hovered; // 0x2c0(0x28)
	struct FSlateColor Colour_Disabled; // 0x2e8(0x28)
	struct FSlateColor Colour_Pressed; // 0x310(0x28)
	struct UMaterialInstance* Image_Normal; // 0x338(0x08)
	struct UMaterialInstance* Image_Pressed; // 0x340(0x08)
	struct UMaterialInstance* Image_Hovered; // 0x348(0x08)
	struct UMaterialInstance* Image_Disabled; // 0x350(0x08)
	struct UTexture2D* IconImage; // 0x358(0x08)
	struct UE4::FText TooltipTextField; // 0x360(0x18)
};


struct UPanelWidget : UWidget {
	struct UE4::TArray<struct UPanelSlot*> Slots; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

struct UHorizontalBox : UPanelWidget {
	char pad_120[0x10]; // 0x120(0x10)
};

enum class ESlateBrushDrawType : uint8_t {
	NoDrawType = 0,
	Box = 1,
	Border = 2,
	Image = 3,
	ESlateBrushDrawType_MAX = 4
};

enum class ESlateBrushTileType : uint8_t {
	NoTile = 0,
	Horizontal = 1,
	Vertical = 2,
	Both = 3,
	ESlateBrushTileType_MAX = 4
};

enum class ESlateBrushMirrorType : uint8_t {
	NoMirror = 0,
	Horizontal = 1,
	Vertical = 2,
	Both = 3,
	ESlateBrushMirrorType_MAX = 4
};

enum class ESlateBrushImageType : uint8_t {
	NoImage = 0,
	FullColor = 1,
	Linear = 2,
	ESlateBrushImageType_MAX = 3
};

struct FSlateBrush {
	char pad_0[0x8]; // 0x00(0x08)
	struct UE4::FVector2D ImageSize; // 0x08(0x08)
	struct FMargin Margin; // 0x10(0x10)
	struct FSlateColor TintColor; // 0x20(0x28)
	struct UObject* ResourceObject; // 0x48(0x08)
	struct UE4::FName ResourceName; // 0x50(0x08)
	struct UE4::FBox2D UVRegion; // 0x58(0x14)
	enum class ESlateBrushDrawType DrawAs; // 0x6c(0x01)
	enum class ESlateBrushTileType tiling; // 0x6d(0x01)
	enum class ESlateBrushMirrorType Mirroring; // 0x6e(0x01)
	enum class ESlateBrushImageType ImageType; // 0x6f(0x01)
	char pad_70[0x10]; // 0x70(0x10)
	char bIsDynamicallyLoaded : 1; // 0x80(0x01)
	char bHasUObject : 1; // 0x80(0x01)
	char pad_80_2 : 6; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

struct FSlateSound {
	struct UObject* ResourceObject; // 0x00(0x08)
	char pad_8[0x10]; // 0x08(0x10)
};

struct FSlateWidgetStyle {
	char pad_0[0x8]; // 0x00(0x08)
};

struct FButtonStyle : FSlateWidgetStyle {
	struct FSlateBrush Normal; // 0x08(0x88)
	struct FSlateBrush Hovered; // 0x90(0x88)
	struct FSlateBrush Pressed; // 0x118(0x88)
	struct FSlateBrush Disabled; // 0x1a0(0x88)
	struct FMargin NormalPadding; // 0x228(0x10)
	struct FMargin PressedPadding; // 0x238(0x10)
	struct FSlateSound PressedSlateSound; // 0x248(0x18)
	struct FSlateSound HoveredSlateSound; // 0x260(0x18)
};

enum class ETextJustify : uint8_t {
	Left = 0,
	Center = 1,
	Right = 2,
	ETextJustify_MAX = 3
};

struct FSessionFlagsRowHandle : FRowHandle {
};

struct FFeatureLevelsRowHandle : FRowHandle {
};

struct UIcarusWidget : UUserWidget {
	struct FFeatureLevelsRowHandle RequiredFeatureLevel; // 0x260(0x18)
	bool bOverrideVisibilityIfFeatureLevelDisabled; // 0x278(0x01)
	enum class ESlateVisibility FeatureLevelVisibilityOverride; // 0x279(0x01)
	char pad_27A[0x6]; // 0x27a(0x06)
};

struct UUMG_ButtonBase_C : UIcarusWidget {
	struct FPointerToUberGraphFrame* UberGraphFrame; // 0x280(0x08)
	char Clicked[0x10]; // 0x2a4(0x04)
	struct UFont* TextFont; // 0x298(0x08)
	int32_t Text_Size; // 0x2a0(0x04)
	char pad_2A4[0x4]; // 0x2a4(0x04)
	struct UE4::FText Text; // 0x2a8(0x18)
	bool Bold; // 0x2c0(0x01)
	bool Italic; // 0x2c1(0x01)
	bool Uppercase; // 0x2c2(0x01)
	char pad_2C3[0x5]; // 0x2c3(0x05)
	struct FSlateColor Text_Normal; // 0x2c8(0x28)
	struct FSlateColor Text_Hovered; // 0x2f0(0x28)
	struct FSlateColor Text_Pressed; // 0x318(0x28)
	struct FSlateColor Text_Disabled; // 0x340(0x28)
	struct UMaterialInstance* Image_Normal; // 0x368(0x08)
	struct UMaterialInstance* Image_Hovered; // 0x370(0x08)
	struct UMaterialInstance* Image_Pressed; // 0x378(0x08)
	struct UMaterialInstance* Image_Disabled; // 0x380(0x08)
	bool Orange; // 0x388(0x01)
	char pad_389[0x7]; // 0x389(0x07)
	struct FSlateColor Text_Orange_Normal; // 0x390(0x28)
	struct FSlateColor Text_Orange_Hovered; // 0x3b8(0x28)
	struct FSlateColor Text_Orange_Pressed; // 0x3e0(0x28)
	struct FSlateColor Text_Orange_Disabled; // 0x408(0x28)
	struct UTextBlock* ButtonTextRef; // 0x430(0x08)
	struct UButton* ImageButtonRef; // 0x438(0x08)
	struct UFMODEvent* Sound_OnClick; // 0x440(0x08)
	struct UE4::FLinearColor CachedTextColor; // 0x448(0x10)
};

struct UUMG_BasicButton_2_C : UUMG_ButtonBase_C {
	struct FPointerToUberGraphFrame* UberGraphFrame; // 0x458(0x08)
	struct UBorder* AdditionalBorder; // 0x460(0x08)
	struct UNamedSlot* AdditionalContent; // 0x468(0x08)
	struct UBackgroundBlur* BackgroundBlur_1; // 0x470(0x08)
	struct UTextBlock* ButtonText; // 0x478(0x08)
	struct UOverlay* HighlightFlagOverlay; // 0x480(0x08)
	struct UButton* ImageButton; // 0x488(0x08)
	struct UScaleBox* ScaleBox_TextContainer; // 0x490(0x08)
	struct USizeBox* SizeBox; // 0x498(0x08)
	struct FButtonStyle NormalStyle; // 0x4a0(0x278)
	float Width; // 0x718(0x04)
	float Height; // 0x71c(0x04)
	enum class ETextJustify Justification; // 0x720(0x01)
	char pad_721[0x3]; // 0x721(0x03)
	struct FSessionFlagsRowHandle HighlightFlag; // 0x724(0x18)
	char pad_73C[0x4]; // 0x73c(0x04)
	struct UUMG_QuestHelper_C* QuestHelper; // 0x740(0x08)
	float BlurStrength; // 0x748(0x04)
	struct FMargin TextPadding; // 0x74c(0x10)
};

struct UImage : UWidget {
	struct FSlateBrush Brush; // 0x108(0x88)
	char BrushDelegate[0x10]; // 0x1c1(0x03)
	struct UE4::FLinearColor ColorAndOpacity; // 0x1a0(0x10)
	char ColorAndOpacityDelegate[0x10]; // 0x1c1(0x03)
	bool bFlipForRightToLeftFlowDirection; // 0x1c0(0x01)
	char pad_1C1[0x3]; // 0x1c1(0x03)
	char OnMouseButtonDownEvent[0x10]; // 0x1c1(0x03)
	char pad_1D4[0x3c]; // 0x1d4(0x3c)
};

struct FAISetupRowHandle : FRowHandle {
};

enum class EMainMenuOptions : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator10 = 3,
	NewEnumerator7 = 4,
	NewEnumerator11 = 5,
	NewEnumerator12 = 6,
	EMainMenuOptions_MAX = 7
};