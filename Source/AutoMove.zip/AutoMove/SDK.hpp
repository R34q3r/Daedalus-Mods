#include "AutoMove.h"
#include "Utilities/MinHook.h"
#include "Ue4.hpp"

struct UVisual : UE4::UObject {
};

struct FMargin {
	float Left; // 0x00(0x04)
	float Top; // 0x04(0x04)
	float Right; // 0x08(0x04)
	float Bottom; // 0x0c(0x04)
};

struct FWidgetTransform {
	struct UE4::FVector2D Translation; // 0x00(0x08)
	struct UE4::FVector2D Scale; // 0x08(0x08)
	struct UE4::FVector2D Shear; // 0x10(0x08)
	float Angle; // 0x18(0x04)
};


enum class EMouseCursor : uint8_t {
	None = 0,
	Default = 1,
	TextEditBeam = 2,
	ResizeLeftRight = 3,
	ResizeUpDown = 4,
	ResizeSouthEast = 5,
	ResizeSouthWest = 6,
	CardinalCross = 7,
	Crosshairs = 8,
	Hand = 9,
	GrabHand = 10,
	GrabHandClosed = 11,
	SlashedCircle = 12,
	EyeDropper = 13,
	EMouseCursor_MAX = 14
};

enum class EWidgetClipping : uint8_t {
	Inherit = 0,
	ClipToBounds = 1,
	ClipToBoundsWithoutIntersecting = 2,
	ClipToBoundsAlways = 3,
	OnDemand = 4,
	EWidgetClipping_MAX = 5
};

enum class ESlateVisibility : uint8_t {
	Visible = 0,
	Collapsed = 1,
	Hidden = 2,
	HitTestInvisible = 3,
	SelfHitTestInvisible = 4,
	ESlateVisibility_MAX = 5
};

enum class EFlowDirectionPreference : uint8_t {
	Inherit = 0,
	Culture = 1,
	LeftToRight = 2,
	RightToLeft = 3,
	EFlowDirectionPreference_MAX = 4
};

struct FPropertyPathSegment {
	struct UE4::FName Name; // 0x00(0x08)
	int32_t ArrayIndex; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct UStruct* Struct; // 0x10(0x08)
	char pad_18[0x10]; // 0x18(0x10)
};

struct FCachedPropertyPath {
	struct UE4::TArray<struct FPropertyPathSegment> Segments; // 0x00(0x10)
	char pad_10[0x8]; // 0x10(0x08)
	struct UFunction* CachedFunction; // 0x18(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

struct FDynamicPropertyPath : FCachedPropertyPath {
};

struct UPropertyBinding : UE4::UObject {
	struct UE4::FVector2D SourceObject; // 0x28(0x08)
	struct FDynamicPropertyPath SourcePath; // 0x30(0x28)
	struct UE4::FName DestinationProperty; // 0x58(0x08)
};

struct UWidget : UVisual {
	struct UPanelSlot* Slot; // 0x28(0x08)
	struct FMargin bIsEnabledDelegate; // 0x30(0x10)
	struct UE4::FText ToolTipText; // 0x40(0x18)
	struct FMargin ToolTipTextDelegate; // 0x58(0x10)
	struct UWidget* ToolTipWidget; // 0x68(0x08)
	struct FMargin ToolTipWidgetDelegate; // 0x70(0x10)
	struct FMargin VisibilityDelegate; // 0x80(0x10)
	struct FWidgetTransform RenderTransform; // 0x90(0x1c)
	struct UE4::FVector2D RenderTransformPivot; // 0xac(0x08)
	char bIsVariable : 1; // 0xb4(0x01)
	char bCreatedByConstructionScript : 1; // 0xb4(0x01)
	char bIsEnabled : 1; // 0xb4(0x01)
	char bOverride_Cursor : 1; // 0xb4(0x01)
	char pad_B4_4 : 4; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	struct USlateAccessibleWidgetData* AccessibleWidgetData; // 0xb8(0x08)
	char bIsVolatile : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	enum class EMouseCursor Cursor; // 0xc1(0x01)
	enum class EWidgetClipping Clipping; // 0xc2(0x01)
	enum class ESlateVisibility Visibility; // 0xc3(0x01)
	float RenderOpacity; // 0xc4(0x04)
	struct UWidgetNavigation* Navigation; // 0xc8(0x08)
	enum class EFlowDirectionPreference FlowDirectionPreference; // 0xd0(0x01)
	char pad_D1[0x27]; // 0xd1(0x27)
	struct UE4::TArray<struct UPropertyBinding*> NativeBindings; // 0xf8(0x10)
};

enum class ESlateColorStylingMode : uint8_t {
	UseColor_Specified = 0,
	UseColor_Specified_Link = 1,
	UseColor_Foreground = 2,
	UseColor_Foreground_Subdued = 3,
	UseColor_MAX = 4
};

struct FSlateColor {
	struct UE4::FLinearColor SpecifiedColor; // 0x00(0x10)
	enum class ESlateColorStylingMode ColorUseRule; // 0x10(0x01)
	char pad_11[0x17]; // 0x11(0x17)
};

struct FMovieSceneSequenceID {
	uint32_t Value; // 0x00(0x04)
};

struct FMovieSceneRootEvaluationTemplateInstance {
	struct UE4::FVector2D WeakRootSequence; // 0x00(0x08)
	struct UMovieSceneCompiledDataManager* CompiledDataManager; // 0x08(0x08)
	char pad_10[0x8]; // 0x10(0x08)
	struct UMovieSceneEntitySystemLinker* EntitySystemLinker; // 0x18(0x08)
	char pad_20[0x70]; // 0x20(0x70)
	struct UE4::TMap<struct FMovieSceneSequenceID, struct UE4::UObject*> DirectorInstances; // 0x90(0x50)
	char pad_E0[0x8]; // 0xe0(0x08)
};

struct UUMGSequencePlayer : UE4::UObject {
	char pad_28[0x238]; // 0x28(0x238)
	struct UWidgetAnimation* Animation; // 0x260(0x08)
	char pad_268[0x8]; // 0x268(0x08)
	struct FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance; // 0x270(0xe8)
	char pad_358[0x70]; // 0x358(0x70)
};

struct FNamedSlotBinding {
	struct UE4::FName Name; // 0x00(0x08)
	struct UWidget* Content; // 0x08(0x08)
};

enum class EWidgetTickFrequency : uint8_t {
	Never = 0,
	Auto = 1,
	EWidgetTickFrequency_MAX = 2
};

enum class EWidgetAnimationEvent : uint8_t {
	Started = 0,
	Finished = 1,
	EWidgetAnimationEvent_MAX = 2
};

struct FAnimationEventBinding {
	struct UWidgetAnimation* Animation; // 0x00(0x08)
	struct UE4::FName Delegate; // 0x08(0x10)
	enum class EWidgetAnimationEvent AnimationEvent; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	struct UE4::FName UserTag; // 0x1c(0x08)
	char pad_24[0x4]; // 0x24(0x04)
};

struct UUserWidget : UWidget {
	char pad_108[0x8]; // 0x108(0x08)
	struct UE4::FLinearColor ColorAndOpacity; // 0x110(0x10)
	struct FMargin ColorAndOpacityDelegate; // 0x120(0x10)
	struct FSlateColor ForegroundColor; // 0x130(0x28)
	struct FMargin ForegroundColorDelegate; // 0x158(0x10)
	struct FMargin OnVisibilityChanged; // 0x168(0x10)
	char pad_178[0x18]; // 0x178(0x18)
	struct FMargin Padding; // 0x190(0x10)
	struct UE4::TArray<struct UUMGSequencePlayer*> ActiveSequencePlayers; // 0x1a0(0x10)
	struct UUMGSequenceTickManager* AnimationTickManager; // 0x1b0(0x08)
	struct UE4::TArray<struct UUMGSequencePlayer*> StoppedSequencePlayers; // 0x1b8(0x10)
	struct UE4::TArray<struct FNamedSlotBinding> NamedSlotBindings; // 0x1c8(0x10)
	struct UWidgetTree* WidgetTree; // 0x1d8(0x08)
	int32_t Priority; // 0x1e0(0x04)
	char bSupportsKeyboardFocus : 1; // 0x1e4(0x01)
	char bIsFocusable : 1; // 0x1e4(0x01)
	char bStopAction : 1; // 0x1e4(0x01)
	char bHasScriptImplementedTick : 1; // 0x1e4(0x01)
	char bHasScriptImplementedPaint : 1; // 0x1e4(0x01)
	char pad_1E4_5 : 3; // 0x1e4(0x01)
	char pad_1E5[0xb]; // 0x1e5(0x0b)
	enum class EWidgetTickFrequency TickFrequency; // 0x1f0(0x01)
	char pad_1F1[0x7]; // 0x1f1(0x07)
	struct UInputComponent* InputComponent; // 0x1f8(0x08)
	struct UE4::TArray<struct FAnimationEventBinding> AnimationCallbacks; // 0x200(0x10)
	char pad_210[0x50]; // 0x210(0x50)
};

struct FTimerHandle {
	uint64_t Handle; // 0x00(0x08)
};

enum class EBPLogVerbosity : uint8_t {
	Fatal = 0,
	Error = 1,
	Warning = 2,
	Display = 3,
	Log = 4,
	Verbose = 5,
	VeryVerbose = 6,
	EBPLogVerbosity_MAX = 7
};

enum class UDLSSMode : uint8_t {
	Off = 0,
	Auto = 1,
	UltraQuality = 2,
	Quality = 3,
	Balanced = 4,
	Performance = 5,
	UltraPerformance = 6,
	UDLSSMode_MAX = 7
};


struct UUMG_MainInventory_C : UUserWidget {
	struct UE4::FName UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* OpenStats; // 0x268(0x08)
	struct UWidgetAnimation* AnimatePointers; // 0x270(0x08)
	struct UUMG_Titlebar_C* Character_Titlebar; // 0x278(0x08)
	struct UImage* Dropshadow; // 0x280(0x08)
	struct UUMG_Titlebar_C* Inventory_Titlebar; // 0x288(0x08)
	struct UHorizontalBox* Keyprompts; // 0x290(0x08)
	struct UButton* ShowMoreButton; // 0x298(0x08)
	struct UTextBlock* ShowMoreText; // 0x2a0(0x08)
	struct UOverlay* StatsWindow; // 0x2a8(0x08)
	struct UImage* SuitImage; // 0x2b0(0x08)
	struct UUMG_BasicButton_2_C* UMG_BasicButton_3; // 0x2b8(0x08)
	struct UUMG_EncumbranceBarLight_C* UMG_EncumbranceBarLight; // 0x2c0(0x08)
	struct UUMG_EnvirosuitSlots_C* UMG_EnvirosuitSlots; // 0x2c8(0x08)
	struct UUMG_Inventory_C* UMG_Inventory; // 0x2d0(0x08)
	struct UUMG_InventoryAuxilarySlots_C* UMG_InventoryAuxilarySlots; // 0x2d8(0x08)
	struct UUMG_InventoryDropZone_C* UMG_InventoryDropZone; // 0x2e0(0x08)
	struct UUMG_InventoryEnvirosuit_C* UMG_InventoryEnvirosuit; // 0x2e8(0x08)
	struct UUMG_InventoryPaperDoll_C* UMG_InventoryPaperDoll; // 0x2f0(0x08)
	struct UUMG_InventoryStatusBox_C* UMG_InventoryStatusBox; // 0x2f8(0x08)
	struct UUMG_StatDisplay_C* UMG_StatDisplay; // 0x300(0x08)
	struct UUMG_StatsWindow_C* UMG_StatsWindow; // 0x308(0x08)
	struct UInventory* Inventory; // 0x310(0x08)
	struct UUMG_UserInterface_C* UserInterface; // 0x318(0x08)
	struct ABP_PlayerPreview_Survival_C* PlayerPreview; // 0x320(0x08)
	enum class UDLSSMode OldDLSSMode; // 0x328(0x01)
	char pad_329[0x7]; // 0x329(0x07)
	struct FTimerHandle TimerHandle; // 0x330(0x08)
	enum class EBPLogVerbosity DebugVerbosity; // 0x338(0x01)
};