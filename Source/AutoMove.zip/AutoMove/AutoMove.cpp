#include "AutoMove.h"
#include "SDK.hpp"
#include "Utilities/MinHook.h"
#include "Ue4.hpp"
#include <filesystem>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <shlobj_core.h>
#include <direct.h>
#include <json/json.h>
#include <thread>
#include <future>

BPFUNCTION(WriteToFile)
{
	std::cout << "WriteToFile" << std::endl;
	struct InputParams
	{
		UE4::FString NameTest;
	};
	auto Inputs = stack->GetInputParams<InputParams>();
	stack->SetOutput<UE4::FString>("OutPutString", L"KboyGang");
	stack->SetOutput<bool>("ReturnValue", true);
}


void LogOther(int32_t value)
{
	Log::Print(std::to_string(value));
}

// Only Called Once, if you need to hook shit, declare some global non changing values
void AutoMove::InitializeMod()
{
	UE4::InitSDK();
	SetupHooks();

	REGISTER_FUNCTION(WriteToFile);

	MinHook::Init(); //Uncomment if you plan to do hooks

	UseMenuButton = true; // Allows Mod Loader To Show Button
}

void AutoMove::InitGameState()
{
}

void AutoMove::ProcessFunctionUObject(UE4::UObject* pCallObject, UE4::UFunction* pUFunc, void* pParms)
{
}

void keyPress(WORD keyCode)
{
	INPUT input;
	input.type = INPUT_KEYBOARD;
	input.ki.wScan = keyCode;
	input.ki.dwFlags = KEYEVENTF_SCANCODE;

	SendInput(1, &input, sizeof(INPUT));
}

void keyRelease(WORD keyCode)
{
	INPUT input;
	input.type = INPUT_KEYBOARD;
	input.ki.wScan = keyCode;
	input.ki.dwFlags = KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP;

	SendInput(1, &input, sizeof(INPUT));
}

int pauseLength = 0;
bool isMoving = false;

void AutoMove::ProcessFunctionAActor(UE4::UObject* pCallObject, UE4::UFunction* pUFunc, void* pParms)
{
	if (pUFunc->GetFullName() == "Function Engine.Actor.ReceiveTick")
		if (pauseLength == 0)
		{
			if (GetKeyState(VK_OEM_PLUS) & 0x8000)
			{
				if (isMoving)
				{
					keyRelease(17);

					isMoving = false;

				}
				else
				{
					keyPress(17);

					isMoving = true;
				}

				pauseLength = 750;
			}
		}
		else 
		{
			pauseLength--;
		}
}

void AutoMove::BeginPlay(UE4::AActor* Actor)
{
}

void AutoMove::PostBeginPlay(std::wstring ModActorName, UE4::AActor* Actor)
{
	// Filters Out All Mod Actors Not Related To Your Mod
	std::wstring TmpModName(ModName.begin(), ModName.end());
	if (ModActorName == TmpModName)
	{
		//Sets ModActor Ref
		ModActor = Actor;
	}
}
void AutoMove::DX11Present(ID3D11Device* pDevice, ID3D11DeviceContext* pContext, ID3D11RenderTargetView* pRenderTargetView)
{
}

void AutoMove::OnModMenuButtonPressed()
{
}

void AutoMove::DrawImGui()
{
}