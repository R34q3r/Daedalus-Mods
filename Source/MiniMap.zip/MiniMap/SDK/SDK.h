#include <Ue4.hpp>

namespace SDK
{
	 UE4::TArray<UE4::UObject> = 0x0;

	void InitFunctions();
};