#include "MiniMap.h"
#include "SDK.hpp"
#include "Utilities/MinHook.h"
#include "Ue4.hpp"
#include <filesystem>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <shlobj_core.h>
#include <direct.h>

BPFUNCTION(WriteToFile)
{
	std::cout << "WriteToFile" << std::endl;
	struct InputParams
	{
		UE4::FString NameTest;
	};
	auto Inputs = stack->GetInputParams<InputParams>();
	stack->SetOutput<UE4::FString>("OutPutString", L"KboyGang");
	stack->SetOutput<bool>("ReturnValue", true);
}

void LogOther(int32_t value)
{
	Log::Print(std::to_string(value));
}

// Only Called Once, if you need to hook shit, declare some global non changing values
void MiniMap::InitializeMod()
{
	UE4::InitSDK();
	SetupHooks();

	REGISTER_FUNCTION(WriteToFile);

	MinHook::Init(); //Uncomment if you plan to do hooks

	UseMenuButton = true; // Allows Mod Loader To Show Button
}

void MiniMap::InitGameState()
{
}

template<typename T>
static T* FindObject(const std::string& name)
{
	for (int i = 0; i < UE4::UObject::GObjects->GetAsChunckArray().Num(); ++i)
	{
		auto object = UE4::UObject::GObjects->GetAsChunckArray().GetByIndex(i).Object;

		if (object == nullptr)
		{
			continue;
		}

		if (object->GetFullName() == name)
		{
			return static_cast<T*>(object);
		}
	}
	return nullptr;
}

//Classes
UE4::UObject* Viewport;
UE4::UObject* UUMG_UserInterface_C;
UE4::UObject* UUMG_MainMenu_C;
UE4::UObject* BP_IcarusPlayerControllerSurvival_C;
UE4::UObject* BP_IcarusPlayerControllerSpace_C;
UE4::UObject* UserInterface;
UE4::UObject* MainMenu;
UE4::UObject* MainMap;
UE4::UObject* UHorizontalBox;
UE4::UObject* UUMG_RadarMainScreen_C;
UE4::UObject* WidgetLayoutLibrary;
UE4::UObject* WidgetBlueprintLibrary;
UE4::UObject* MapParent;
FWidgetTransform OldTransform;

//Functions
UE4::UFunction* RemoveFromParent;
UE4::UFunction* AddToViewport;
UE4::UFunction* UpdateMapVisibility;
UE4::UFunction* SetPadding;
UE4::UFunction* SetVisibility;
UE4::UFunction* BndEvt__CenterMapButton_K2Node_ComponentBoundEvent_2_Clicked__DelegateSignature;
UE4::UFunction* BndEvt__ToggleRadarButton_K2Node_ComponentBoundEvent_8_Clicked__DelegateSignature;
UE4::UFunction* SetDesiredSizeInViewport;
UE4::UFunction* SetRenderTranslation;
UE4::UFunction* SetAnchorsInViewport;
UE4::UFunction* GetViewportSize;
UE4::UFunction* ToggleRadarDisplay;
UE4::UFunction* Create;
UE4::UFunction* GetParentFunc;
UE4::UFunction* AddChild;
UE4::UFunction* RemoveFromViewport;
UE4::UFunction* GetAlignmentInViewport;
UE4::UFunction* GetDesiredSize;
UE4::UFunction* UpdateRadarWidgets;
UE4::UFunction* LoadHeightmapsIntoMapTiles;
UE4::UFunction* BatchDrawFOW;
UE4::UFunction* GetShownMenu;

bool logAll = false;
bool charactorInit = false;

bool inInventory = false;
bool inSettings = false;
bool inMap = false;

UE4::UObject* legendDropship;
UE4::UObject* downedPlayer;
UE4::UObject* player;

UE4::UObject* ButtonMapCombined;
UE4::UObject* ButtonMapTopo;
UE4::UObject* ButtonMapVisual;
UE4::UObject* CenterMapButton;
UE4::UObject* ToggleRadarButton;

UE4::UObject* UMG_BasicButton_CenterMap;
UE4::UObject* UMG_BasicButton_Combined;
UE4::UObject* UMG_BasicButton_ToggleRadar;
UE4::UObject* UMG_BasicButton_Topographical;
UE4::UObject* UMG_BasicButton_Visual;

UE4::UObject* TranslationCanvas;

 UE4::UObject* Image;
 UE4::UObject* Image_2;
 UE4::UObject* Image_3;
 UE4::UObject* Image_4;
 UE4::UObject* Image_5;
 UE4::UObject* Image_6;
 UE4::UObject* Image_7;
 UE4::UObject* Image_8;
 UE4::UObject* Image_9;
 UE4::UObject* Image_10;
 UE4::UObject* Image_11;
 UE4::UObject* Image_12;
 UE4::UObject* Image_13;
 UE4::UObject* Image_14;
 UE4::UObject* Image_547;
 UE4::UObject* Image_715;
 UE4::UObject* Image_730;
 UE4::UObject* Imagex;
 UE4::UObject* Image_60;

UE4::FVector2D LocationMenu;
UE4::FVector2D SizeMenu;

UE4::FVector2D LocationMini;
UE4::FVector2D SizeMini;

void Hide(UE4::UObject* object)
{
	struct
	{
		enum class ESlateVisibility InVisibility;
	}SetVisibilityParams;

	SetVisibilityParams.InVisibility = ESlateVisibility::Hidden;

	object->ProcessEvent(SetVisibility, &SetVisibilityParams);
}

void Show(UE4::UObject* object)
{
	struct
	{
		enum class ESlateVisibility InVisibility;
	}SetVisibilityParams;

	SetVisibilityParams.InVisibility = ESlateVisibility::Visible;

	object->ProcessEvent(SetVisibility, &SetVisibilityParams);
}

void Remove(UE4::UObject* object)
{
	object->ProcessEvent(RemoveFromParent, nullptr);
}

void MiniMap::ProcessFunctionAActor(UE4::UObject* pCallObject, UE4::UFunction* pUFunc, void* pParms)
{
	if (pUFunc->GetFullName() == "Function BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C.ReceiveTick")
	{
		if (UUMG_RadarMainScreen_C != nullptr && *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2c0) != nullptr && !inInventory && !inSettings && !inMap)
		{
			UUMG_RadarMainScreen_C->ProcessEvent(BndEvt__CenterMapButton_K2Node_ComponentBoundEvent_2_Clicked__DelegateSignature, nullptr);
		}
		else 
		{
			UserInterface = *(UE4::UObject**)(BP_IcarusPlayerControllerSurvival_C + 0x8e0);
			MainMenu = *(UE4::UObject**)(UserInterface + 0x588);
			MainMap = *(UE4::UObject**)(MainMenu + 0x360);
			UUMG_RadarMainScreen_C = *(UE4::UObject**)(MainMap + 0x298);

			if (UUMG_RadarMainScreen_C != nullptr && *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2c0) != nullptr)
			{
				charactorInit = true;
			}
			else
			{
				charactorInit = false;
			}
		}
	}
}

int32_t first = 0;

void MiniMap::ProcessFunctionUObject(UE4::UObject* pCallObject, UE4::UFunction* pUFunc, void* pParms)
{
	if (pCallObject->GetClass()->GetName() == "BP_IcarusPlayerControllerSurvival_C" || pCallObject->GetClass()->GetName() == "UMG_RadarMainScreen_C" || pCallObject->GetClass()->GetName() == "UMG_EscapeMenu_C")
	{
		if (pUFunc->GetFullName() == "Function UMG_RadarMainScreen.UMG_RadarMainScreen_C.OnLoaded_170E4BB94C9E0BCCC204CD833F0BCCC2")
		{
			if (first == 1)
			{
				struct
				{
					float DrawSizeOverride;
				}BatchDrawFOWParams;

				BatchDrawFOWParams.DrawSizeOverride = 100;

				UUMG_RadarMainScreen_C->ProcessEvent(BatchDrawFOW, &BatchDrawFOWParams);

				UUMG_RadarMainScreen_C->ProcessEvent(ToggleRadarDisplay, nullptr);

				first++;
			}
			else
			{
				first++;
			}
		}
		else if (pUFunc->GetFullName() == "Function BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C.InpActEvt_Map_K2Node_InputActionEvent_10")
		{
			if (inMap)
			{
				inMap = !inMap;

				struct
				{
					enum class ESlateVisibility InVisibility;
				}SetVisibilityParams;

				SetVisibilityParams.InVisibility = ESlateVisibility::Hidden;

				Hide(UMG_BasicButton_Topographical);
				Hide(ButtonMapTopo);

				Hide(UMG_BasicButton_Combined);
				Hide(ButtonMapCombined);

				Hide(UMG_BasicButton_ToggleRadar);
				Hide(ToggleRadarButton);

				Hide(UMG_BasicButton_Visual);
				Hide(ButtonMapVisual);

				Hide(UMG_BasicButton_CenterMap);
				Hide(CenterMapButton);

				Hide(Image);
				Hide(Image_2);
				Hide(Image_3);
				Hide(Image_4);
				Hide(Image_5);
				Hide(Image_6);
				Hide(Image_7);
				Hide(Image_8);
				Hide(Image_9);
				Hide(Image_10);
				Hide(Image_11);
				Hide(Image_12);
				Hide(Image_13);
				Hide(Image_14);
				Hide(Image_547);
				Hide(Image_715);
				Hide(Image_730);

				//MainMap->ProcessEvent(RemoveFromParent, nullptr);

				struct
				{
					int32_t ZOrder;
				}AddToViewportParams;

				AddToViewportParams.ZOrder = 1;

				MainMap->ProcessEvent(AddToViewport, &AddToViewportParams);

				FMargin newMargin;

				struct
				{
					struct UE4::FVector2D Size;
				}SetDesiredSizeInViewportParams;

				struct
				{
					struct UE4::FVector2D Translation;
				}SetRenderTranslationParams;

				SetDesiredSizeInViewportParams.Size.X = SizeMini.X;
				SetDesiredSizeInViewportParams.Size.Y = SizeMini.X;

				SetRenderTranslationParams.Translation.X = LocationMini.X;
				SetRenderTranslationParams.Translation.Y = LocationMini.Y;

				MainMap->ProcessEvent(SetDesiredSizeInViewport, &SetDesiredSizeInViewportParams);

				MainMap->ProcessEvent(SetRenderTranslation, &SetRenderTranslationParams);
			}
			else if (!inInventory && !inSettings)
			{
				inMap = !inMap;

				struct
				{
					enum class ESlateVisibility InVisibility;
				}SetVisibilityParams;

				SetVisibilityParams.InVisibility = ESlateVisibility::Hidden;

				Show(UMG_BasicButton_Topographical);
				Show(ButtonMapTopo);

				Show(UMG_BasicButton_Combined);
				Show(ButtonMapCombined);

				Show(UMG_BasicButton_ToggleRadar);
				Show(ToggleRadarButton);

				Show(UMG_BasicButton_Visual);
				Show(ButtonMapVisual);

				Show(UMG_BasicButton_CenterMap);
				Show(CenterMapButton);

				UUMG_RadarMainScreen_C->ProcessEvent(BndEvt__ToggleRadarButton_K2Node_ComponentBoundEvent_8_Clicked__DelegateSignature, nullptr);
				UUMG_RadarMainScreen_C->ProcessEvent(BndEvt__ToggleRadarButton_K2Node_ComponentBoundEvent_8_Clicked__DelegateSignature, nullptr);

				struct
				{
					struct UE4::UObject* ReturnValue;
					struct UE4::UObject* Content;
				}AddChildParams;

				AddChildParams.Content = MainMap;

				//MainMap->ProcessEvent(RemoveFromViewport, nullptr);

				AddChildParams.ReturnValue = 0;

				MapParent->ProcessEvent(AddChild, &AddChildParams);

				AddChildParams.ReturnValue = 0;

				struct
				{
					struct UE4::FVector2D Size;
				}SetDesiredSizeInViewportParams;

				struct
				{
					struct UE4::FVector2D Translation;
				}SetRenderTranslationParams;

				SetDesiredSizeInViewportParams.Size.X = SizeMenu.X;
				SetDesiredSizeInViewportParams.Size.Y = SizeMenu.Y;

				SetRenderTranslationParams.Translation.X = LocationMenu.X;
				SetRenderTranslationParams.Translation.Y = LocationMenu.Y;

				MainMap->ProcessEvent(SetDesiredSizeInViewport, &SetDesiredSizeInViewportParams);

				MainMap->ProcessEvent(SetRenderTranslation, &SetRenderTranslationParams);
			}
		}
		else if (pUFunc->GetFullName() == "Function BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C.InpActEvt_Escape_K2Node_InputActionEvent_9")
		{
			if (inSettings)
			{
				Show(MainMap);
			}
			else if (!inInventory && !inSettings && !inInventory)
			{
				Hide(MainMap);
			}
			else
			{
				inInventory = false;
				inMap = false;

				Show(MainMap);
			}

			inSettings = !inSettings;
		}
		else if (pUFunc->GetFullName() == "Function BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C.InpActEvt_Tech_K2Node_InputActionEvent_11" || pUFunc->GetFullName() == "Function BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C.InpActEvt_Crafting_K2Node_InputActionEvent_12" || pUFunc->GetFullName() == "Function BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C.InpActEvt_Inventory_K2Node_InputActionEvent_13")
		{
			if (inInventory)
			{
				Show(MainMap);
			}
			else
			{
				Hide(MainMap);
			}

			inInventory = !inInventory;
		}
		else if (pUFunc->GetFullName() == "Function BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C.InpActEvt_ToggleMenus_K2Node_InputActionEvent_6")
		{
			if (inInventory)
			{
				inInventory = !inInventory;

				struct
				{
					enum class ESlateVisibility InVisibility;
				}SetVisibilityParams;

				SetVisibilityParams.InVisibility = ESlateVisibility::Hidden;

				Hide(UMG_BasicButton_Topographical);
				Hide(ButtonMapTopo);

				Hide(UMG_BasicButton_Combined);
				Hide(ButtonMapCombined);

				Hide(UMG_BasicButton_ToggleRadar);
				Hide(ToggleRadarButton);

				Hide(UMG_BasicButton_Visual);
				Hide(ButtonMapVisual);

				Hide(UMG_BasicButton_CenterMap);
				Hide(CenterMapButton);

				Hide(Image);
				Hide(Image_2);
				Hide(Image_3);
				Hide(Image_4);
				Hide(Image_5);
				Hide(Image_6);
				Hide(Image_7);
				Hide(Image_8);
				Hide(Image_9);
				Hide(Image_10);
				Hide(Image_11);
				Hide(Image_12);
				Hide(Image_13);
				Hide(Image_14);
				Hide(Image_547);
				Hide(Image_715);
				Hide(Image_730);

				//MainMap->ProcessEvent(RemoveFromParent, nullptr);

				struct
				{
					int32_t ZOrder;
				}AddToViewportParams;

				AddToViewportParams.ZOrder = 1;

				MainMap->ProcessEvent(AddToViewport, &AddToViewportParams);

				FMargin newMargin;

				struct
				{
					struct UE4::FVector2D Size;
				}SetDesiredSizeInViewportParams;

				struct
				{
					struct UE4::FVector2D Translation;
				}SetRenderTranslationParams;

				SetDesiredSizeInViewportParams.Size.X = SizeMini.X;
				SetDesiredSizeInViewportParams.Size.Y = SizeMini.X;

				SetRenderTranslationParams.Translation.X = LocationMini.X;
				SetRenderTranslationParams.Translation.Y = LocationMini.Y;

				MainMap->ProcessEvent(SetDesiredSizeInViewport, &SetDesiredSizeInViewportParams);

				MainMap->ProcessEvent(SetRenderTranslation, &SetRenderTranslationParams);

				Show(MainMap);
			}
			else if (!inInventory && !inMap)
			{
				inInventory = !inInventory;

				struct
				{
					enum class EMainMenuOptions Menu;
				}GetShownMenuParams;

				MainMenu->ProcessEvent(GetShownMenu, &GetShownMenuParams);

				if ((int32_t)GetShownMenuParams.Menu == 4)
				{
					struct
					{
						enum class ESlateVisibility InVisibility;
					}SetVisibilityParams;

					SetVisibilityParams.InVisibility = ESlateVisibility::Hidden;

					Show(UMG_BasicButton_Topographical);
					Show(ButtonMapTopo);

					Show(UMG_BasicButton_Combined);
					Show(ButtonMapCombined);

					Show(UMG_BasicButton_ToggleRadar);
					Show(ToggleRadarButton);

					Show(UMG_BasicButton_Visual);
					Show(ButtonMapVisual);

					Show(UMG_BasicButton_CenterMap);
					Show(CenterMapButton);

					UUMG_RadarMainScreen_C->ProcessEvent(BndEvt__ToggleRadarButton_K2Node_ComponentBoundEvent_8_Clicked__DelegateSignature, nullptr);
					UUMG_RadarMainScreen_C->ProcessEvent(BndEvt__ToggleRadarButton_K2Node_ComponentBoundEvent_8_Clicked__DelegateSignature, nullptr);

					struct
					{
						struct UE4::UObject* ReturnValue;
						struct UE4::UObject* Content;
					}AddChildParams;

					AddChildParams.Content = MainMap;

					AddChildParams.ReturnValue = 0;

					MapParent->ProcessEvent(AddChild, &AddChildParams);

					AddChildParams.ReturnValue = 0;

					struct
					{
						struct UE4::FVector2D Size;
					}SetDesiredSizeInViewportParams;

					struct
					{
						struct UE4::FVector2D Translation;
					}SetRenderTranslationParams;

					SetDesiredSizeInViewportParams.Size.X = SizeMenu.X;
					SetDesiredSizeInViewportParams.Size.Y = SizeMenu.Y;

					SetRenderTranslationParams.Translation.X = LocationMenu.X;
					SetRenderTranslationParams.Translation.Y = LocationMenu.Y;

					MainMap->ProcessEvent(SetDesiredSizeInViewport, &SetDesiredSizeInViewportParams);

					MainMap->ProcessEvent(SetRenderTranslation, &SetRenderTranslationParams);
				}
				else
				{
					Hide(MainMap);
				}
			}
		}
		else if (pUFunc->GetFullName() == "Function UMG_EscapeMenu.UMG_EscapeMenu_C.BndEvt__UMG_BasicButton_Return_K2Node_ComponentBoundEvent_2_Clicked__DelegateSignature")
		{
			inSettings = false;
			inInventory = false;
			inMap = false;

			Show(MainMap);
		}
	}
}

void SetValues()
{
	UserInterface = *(UE4::UObject**)(BP_IcarusPlayerControllerSurvival_C + 0x8e0);
	MainMenu = *(UE4::UObject**)(UserInterface + 0x588);
	MainMap = *(UE4::UObject**)(MainMenu + 0x360);
	UUMG_RadarMainScreen_C = *(UE4::UObject**)(MainMap + 0x298);

	legendDropship = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x368);
	downedPlayer = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x360);
	player = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x398);

	ButtonMapCombined = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x290);
	ButtonMapTopo = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x298);
	ButtonMapVisual = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2a0);
	CenterMapButton = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2a8);
	ToggleRadarButton = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x400);

	UMG_BasicButton_CenterMap = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x420);
	UMG_BasicButton_Combined = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x428);
	UMG_BasicButton_ToggleRadar = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x430);
	UMG_BasicButton_Topographical = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x438);
	UMG_BasicButton_Visual = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x440);

	TranslationCanvas = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x408);

	Image = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2c0); // 0x2c0(0x08)
	Image_2 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2c8); // 0x2c8(0x08)
	Image_3 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2d0); // 0x2d0(0x08)
	Image_4 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2d8); // 0x2d8(0x08)
	Image_5 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2e0); // 0x2e0(0x08)
	Image_6 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2e8); // 0x2e8(0x08)
	Image_7 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2f0); // 0x2f0(0x08)
	Image_8 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x2f8); // 0x2f8(0x08)
	Image_9 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x300); // 0x300(0x08)
	Image_10 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x308); // 0x308(0x08)
	Image_11 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x310); // 0x310(0x08)
	Image_12 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x318); // 0x318(0x08)
	Image_13 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x320); // 0x320(0x08)
	Image_14 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x328); // 0x328(0x08)
	Image_547 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x330); // 0x330(0x08)
	Image_715 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x338); // 0x338(0x08)
	Image_730 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x340); // 0x340(0x08)
	Imagex = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x278); // 0x278(0x08)
	Image_60 = *(UE4::UObject**)(UUMG_RadarMainScreen_C + 0x280); // 0x280(0x08)

	UHorizontalBox = *(UE4::UObject**)(MainMap + 0x288); // 0x280(0x08)
}

bool worldSettingsFound = false;

void MiniMap::BeginPlay(UE4::AActor* Actor)
{
	if (Actor->GetClass()->GetFullName() == "BlueprintGeneratedClass BP_IcarusPlayerControllerSurvival.BP_IcarusPlayerControllerSurvival_C")
	{
		BP_IcarusPlayerControllerSurvival_C = Actor;

		//Classes
		WidgetLayoutLibrary = FindObject<UE4::UObject>("Class UMG.WidgetLayoutLibrary");
		WidgetBlueprintLibrary = FindObject<UE4::UObject>("Class UMG.WidgetBlueprintLibrary");

		//Functions
		RemoveFromParent = FindObject<UE4::UFunction>("Function UMG.Widget.RemoveFromParent");
		AddToViewport = FindObject<UE4::UFunction>("Function UMG.UserWidget.AddToViewport");
		RemoveFromViewport = FindObject<UE4::UFunction>("Function UMG.UserWidget.RemoveFromViewport");
		UpdateMapVisibility = FindObject<UE4::UFunction>("Function UMG_MainMap.UMG_MainMap_C.UpdateMapVisibility");	
		SetVisibility = FindObject<UE4::UFunction>("Function UMG.Widget.SetVisibility");
		BndEvt__CenterMapButton_K2Node_ComponentBoundEvent_2_Clicked__DelegateSignature = FindObject<UE4::UFunction>("Function UMG_RadarMainScreen.UMG_RadarMainScreen_C.BndEvt__CenterMapButton_K2Node_ComponentBoundEvent_2_Clicked__DelegateSignature");
		SetDesiredSizeInViewport = FindObject<UE4::UFunction>("Function UMG.UserWidget.SetDesiredSizeInViewport");
		SetAnchorsInViewport = FindObject<UE4::UFunction>("Function UMG.UserWidget.SetAnchorsInViewport");
		GetViewportSize = FindObject<UE4::UFunction>("Function Engine.PlayerController.GetViewportSize");
		SetRenderTranslation = FindObject<UE4::UFunction>("Function UMG.Widget.SetRenderTranslation");		
		ToggleRadarDisplay = FindObject<UE4::UFunction>("Function UMG_RadarMainScreen.UMG_RadarMainScreen_C.BndEvt__ToggleRadarButton_K2Node_ComponentBoundEvent_8_Clicked__DelegateSignature");
		Create = FindObject<UE4::UFunction>("Function UMG.WidgetBlueprintLibrary.Create");
		GetParentFunc = FindObject<UE4::UFunction>("Function UMG.Widget.GetParent");
		AddChild = FindObject<UE4::UFunction>("Function UMG.PanelWidget.AddChild");
		GetAlignmentInViewport = FindObject<UE4::UFunction>("Function UMG.UserWidget.GetAlignmentInViewport");
		GetDesiredSize = FindObject<UE4::UFunction>("Function UMG.Widget.GetDesiredSize");
		BndEvt__ToggleRadarButton_K2Node_ComponentBoundEvent_8_Clicked__DelegateSignature = FindObject<UE4::UFunction>("Function UMG_RadarMainScreen.UMG_RadarMainScreen_C.BndEvt__ToggleRadarButton_K2Node_ComponentBoundEvent_8_Clicked__DelegateSignature");
		UpdateRadarWidgets = FindObject<UE4::UFunction>("Function UMG_RadarMainScreen.UMG_RadarMainScreen_C.UpdateRadarWidgets");
		LoadHeightmapsIntoMapTiles = FindObject<UE4::UFunction>("Function UMG_RadarMainScreen.UMG_RadarMainScreen_C.LoadHeightmapsIntoMapTiles");
		BatchDrawFOW = FindObject<UE4::UFunction>("Function UMG_RadarMainScreen.UMG_RadarMainScreen_C.BatchDrawFOW");
		GetShownMenu = FindObject<UE4::UFunction>("Function UMG_MainMenu.UMG_MainMenu_C.Get Shown Menu");
		
		struct
		{
			int32_t SizeX;
			int32_t SizeY;
		}GetViewportSizeParams;

		BP_IcarusPlayerControllerSurvival_C->ProcessEvent(GetViewportSize, &GetViewportSizeParams);

		LocationMenu.X = 0;
		LocationMenu.Y = (GetViewportSizeParams.SizeY / 9) - 17;

		SizeMenu.Y = (GetViewportSizeParams.SizeY - (GetViewportSizeParams.SizeY / 8) - 473);
		SizeMenu.X = GetViewportSizeParams.SizeX - 630;

		SizeMini.X = (GetViewportSizeParams.SizeX / 100.0f) * 15.0f;
		SizeMini.Y = (GetViewportSizeParams.SizeX / 100.0f) * 15.0f;

		LocationMini.X = GetViewportSizeParams.SizeX - 570 - SizeMini.X - 100;
		LocationMini.Y = GetViewportSizeParams.SizeY - 340 - SizeMini.Y - 70;
	}
	else if (Actor->GetClass()->GetFullName() == "BlueprintGeneratedClass BP_IcarusWorldSettings.BP_IcarusWorldSettings_C" && charactorInit)
	{
		if (!worldSettingsFound)
		{
			worldSettingsFound = true;

			charactorInit = false;

			SetValues();

			struct
			{
				enum class ESlateVisibility InVisibility;
			}SetVisibilityParams;

			SetVisibilityParams.InVisibility = ESlateVisibility::Hidden;

			Hide(UMG_BasicButton_Topographical);
			Hide(ButtonMapTopo);

			Hide(UMG_BasicButton_Combined);
			Hide(ButtonMapCombined);

			Hide(UMG_BasicButton_ToggleRadar);
			Hide(ToggleRadarButton);

			Hide(UMG_BasicButton_Visual);
			Hide(ButtonMapVisual);

			Hide(UMG_BasicButton_CenterMap);
			Hide(CenterMapButton);

			Remove(legendDropship);
			Remove(player);
			Remove(downedPlayer);

			Remove(UHorizontalBox);

			Hide(Image);
			Hide(Image_2);
			Hide(Image_3);
			Hide(Image_4);
			Hide(Image_5);
			Hide(Image_6);
			Hide(Image_7);
			Hide(Image_8);
			Hide(Image_9);
			Hide(Image_10);
			Hide(Image_11);
			Hide(Image_12);
			Hide(Image_13);
			Hide(Image_14);
			Hide(Image_547);
			Hide(Image_715);
			Hide(Image_730);

			struct
			{
				struct UE4::FVector2D ReturnValue;
			}GetDesiredSizeParams;

			MainMap->ProcessEvent(GetDesiredSize, &GetDesiredSizeParams);

			struct
			{
				struct UE4::UObject* ReturnValue;
			}GetParentParams;

			MainMap->ProcessEvent(GetParentFunc, &GetParentParams);

			MapParent = GetParentParams.ReturnValue;

			MainMap->ProcessEvent(RemoveFromParent, nullptr);

			struct
			{
				int32_t ZOrder;
			}AddToViewportParams;

			AddToViewportParams.ZOrder = 1;

			MainMap->ProcessEvent(AddToViewport, &AddToViewportParams);

			MainMap->ProcessEvent(UpdateMapVisibility, nullptr);

			FMargin newMargin;

			struct
			{
				struct UE4::FVector2D Size;
			}SetDesiredSizeInViewportParams;

			struct
			{
				struct UE4::FVector2D Translation;
			}SetRenderTranslationParams;

			SetDesiredSizeInViewportParams.Size.X = SizeMini.X;
			SetDesiredSizeInViewportParams.Size.Y = SizeMini.X;

			SetRenderTranslationParams.Translation.X = LocationMini.X;
			SetRenderTranslationParams.Translation.Y = LocationMini.Y;

			MainMap->ProcessEvent(SetDesiredSizeInViewport, &SetDesiredSizeInViewportParams);

			MainMap->ProcessEvent(SetRenderTranslation, &SetRenderTranslationParams);
		}
	}
}

void MiniMap::PostBeginPlay(std::wstring ModActorName, UE4::AActor* Actor)
{
	// Filters Out All Mod Actors Not Related To Your Mod
	std::wstring TmpModName(ModName.begin(), ModName.end());
	if (ModActorName == TmpModName)
	{
		//Sets ModActor Ref
		ModActor = Actor;
	}
}
void MiniMap::DX11Present(ID3D11Device* pDevice, ID3D11DeviceContext* pContext, ID3D11RenderTargetView* pRenderTargetView)
{
}

void MiniMap::OnModMenuButtonPressed()
{
}

void MiniMap::DrawImGui()
{
}